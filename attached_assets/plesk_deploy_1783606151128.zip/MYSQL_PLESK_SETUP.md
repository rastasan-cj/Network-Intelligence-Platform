# دليل إعداد 249Shadow على Plesk + MySQL

## المتطلبات

- Plesk Obsidian أو أحدث
- PHP 8.0+
- MySQL 5.7+ أو MariaDB 10.4+
- Node.js 18+ (للبناء فقط — اختياري على السيرفر)

---

## خطوات الإعداد

### 1. رفع الملفات

```bash
# ارفع plesk_deploy.zip إلى جذر النطاق
unzip plesk_deploy.zip -d /var/www/vhosts/yourdomain.com/httpdocs/
```

الهيكل المتوقع بعد الاستخراج:
```
httpdocs/
├── public/
│   ├── api/          ← PHP backend
│   ├── dist/         ← React frontend (مبني)
│   ├── .htaccess
│   └── version.json
└── ...
```

### 2. إنشاء قاعدة البيانات (Plesk)

1. افتح **Plesk → Databases → Add Database**
2. اسم القاعدة: `shadow249` (أو أي اسم تريده)
3. أنشئ مستخدماً وكلمة مرور
4. افتح **phpMyAdmin** واستورد الـ Schema:

```bash
mysql -u DB_USER -p DB_NAME < public/api/schema.sql
```

أو عبر phpMyAdmin: **Import → اختر `public/api/schema.sql`**

### 3. ضبط الإعدادات

عدّل الملف `public/api/config.php`:

```php
$_ENV['DB_HOST']      = 'localhost';
$_ENV['DB_PORT']      = '3306';
$_ENV['DB_NAME']      = 'shadow249';        // ← اسم قاعدة البيانات
$_ENV['DB_USER']      = 'your_db_user';     // ← مستخدم DB
$_ENV['DB_PASS']      = 'your_db_password'; // ← كلمة مرور DB
$_ENV['JWT_SECRET']   = 'CHANGE_ME_64_CHAR_RANDOM_SECRET_HERE';
$_ENV['CORS_ORIGINS'] = 'https://yourdomain.com';
$_ENV['FRONTEND_URL'] = 'https://yourdomain.com';
```

> ⚠️ **JWT_SECRET** يجب أن يكون عشوائياً وطويلاً (64+ حرف):
> ```bash
> openssl rand -hex 64
> ```

### 4. إنشاء حساب المدير

```bash
cd /var/www/vhosts/yourdomain.com/httpdocs/public/api
php create_admin.php admin admin@yourdomain.com "YourStr0ngP@ss!"

# احذف السكريبت فور الانتهاء!
rm create_admin.php
```

**بيانات الدخول الافتراضية** (إن استخدمت schema.sql مباشرة):
- رابط: `https://yourdomain.com/admin`
- مستخدم: `admin`
- كلمة المرور: `Admin@249shadow`

> ⚠️ **غيّر كلمة المرور فوراً بعد أول تسجيل دخول!**

### 5. إعداد Apache / Plesk Document Root

في Plesk، اضبط **Document Root** ليشير إلى:
```
/var/www/vhosts/yourdomain.com/httpdocs/public
```

أو أضف `Alias` في إعدادات Apache ليوجّه إلى `public/`.

---

## إعداد PHP في Plesk

في **Plesk → PHP Settings** للنطاق:

| الإعداد | القيمة |
|---------|--------|
| PHP Version | 8.0 أو أحدث |
| upload_max_filesize | 20M |
| post_max_size | 25M |
| max_execution_time | 60 |
| memory_limit | 128M |

---

## التحقق من التثبيت

افتح المتصفح وتحقق:
```
https://yourdomain.com/api/health
```

المتوقع:
```json
{"status": "ok", "platform": "249Shadow", "version": "2.0"}
```

---

## هيكل الملفات على السيرفر

```
httpdocs/public/
├── api/
│   ├── index.php      ← نقطة دخول API
│   ├── config.php     ← إعدادات (DB + JWT + CORS)
│   ├── schema.sql     ← مخطط قاعدة البيانات
│   └── src/
│       ├── DB.php
│       ├── Auth.php
│       ├── JWT.php
│       ├── Response.php
│       ├── ActivityLog.php
│       ├── EmailService.php
│       └── controllers/
├── dist/              ← React مبني (HTML + JS + CSS)
│   ├── index.html
│   └── assets/
├── .htaccess          ← Apache SPA routing
└── version.json
```

---

## استكشاف الأخطاء

| المشكلة | الحل |
|---------|------|
| خطأ 500 عند API | تحقق من `config.php` و بيانات DB |
| الصفحات لا تُحمّل | تحقق من `.htaccess` وتفعيل `mod_rewrite` |
| خطأ CORS | أضف نطاقك في `CORS_ORIGINS` بـ `config.php` |
| لا يمكن تسجيل الدخول | تأكد من تطبيق `schema.sql` وإنشاء Admin |

---

*249Shadow Platform v2.0 — جميع الحقوق محفوظة © 2025*
