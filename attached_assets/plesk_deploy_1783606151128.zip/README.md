# 249Shadow Platform v2.0

منصة تعليمية متكاملة للأمن السيبراني — مبنية بـ React 19 + PHP 8 + MySQL

---

## نظرة عامة

**249Shadow** منصة تعليمية متخصصة في الأمن السيبراني تقدم:
- **تحديات CTF** (Capture The Flag) بفئات متعددة مع نظام نقاط وفِرق
- **دورات تعليمية** مع فصول ودروس ونظام تسجيل
- **سوق مشاريع وعمل حر** مع إدارة طلبات الانضمام
- **مختبر تقني** لتحديات التطبيق العملي
- **لوحة إدارة شاملة** لإدارة المحتوى والمستخدمين والإعدادات
- **نظام شارات وإنجازات** يُفعَّل بناءً على أنشطة المستخدم
- **إشعارات داخلية** ونظام سجل النشاطات

---

## Stack التقني

| الطبقة | التقنية |
|--------|---------|
| Frontend | React 19, Vite 6, React Router Dom 7 |
| تصميم | Tailwind CSS, Lucide React |
| رسوم بيانية | Recharts |
| Backend | PHP 8 (مُدخل موحّد: `backend/public/api/index.php`) |
| قاعدة البيانات | MySQL / MariaDB |
| المصادقة | JWT مخصص — HMAC-SHA256 (Access + Refresh Tokens) |
| النشر | Plesk / Apache |
| اللغة | عربية بالكامل (RTL) مع دعم إنجليزي |

---

## بنية المشروع

```
249shadow-platform/
├── backend/
│   ├── public/
│   │   └── api/
│   │       ├── index.php          ← الموجّه الرئيسي لجميع نقاط API
│   │       ├── config.php         ← إعدادات البيئة (DB, JWT, CORS)
│   │       ├── create_admin.php   ← سكريبت إنشاء حساب المدير (يُحذف بعد الاستخدام)
│   │       └── src/
│   │           ├── DB.php         ← مُغلِّف PDO للاتصال بقاعدة البيانات
│   │           ├── Auth.php       ← إدارة المصادقة والجلسات
│   │           ├── JWT.php        ← ترميز وفكّ ترميز JWT
│   │           ├── Response.php   ← مساعد ردود JSON
│   │           ├── ActivityLog.php← سجل النشاطات
│   │           ├── EmailService.php← خدمة البريد الإلكتروني
│   │           └── controllers/
│   │               ├── AuthController.php
│   │               ├── UserController.php
│   │               ├── CtfController.php
│   │               ├── CourseController.php
│   │               ├── LabController.php
│   │               ├── ProjectController.php
│   │               ├── FreelancerController.php
│   │               ├── TeamController.php
│   │               ├── BadgeController.php
│   │               ├── CommentController.php
│   │               ├── NotificationController.php
│   │               ├── SettingsController.php
│   │               └── AdminCompetitions...
│   └── schema.sql                 ← مخطط قاعدة البيانات الكامل + بيانات البذر
│
└── frontend/
    ├── src/
    │   ├── App.jsx                ← تعريف المسارات (Routes)
    │   ├── context/
    │   │   ├── AuthContext.jsx    ← إدارة الجلسة والمستخدم
    │   │   ├── LanguageContext.jsx← نظام الترجمة (عربي/إنجليزي)
    │   │   └── ThemeContext.jsx   ← الوضع الليلي/النهاري
    │   ├── lib/
    │   │   └── api.js             ← عميل Fetch مركزي مع تجديد JWT تلقائياً
    │   ├── pages/
    │   │   ├── HomePage.jsx
    │   │   ├── LoginPage.jsx      ← واجهة عربية كاملة
    │   │   ├── SignupPage.jsx     ← واجهة عربية كاملة
    │   │   ├── CtfPage.jsx
    │   │   ├── CoursesPage.jsx
    │   │   ├── LeaderboardPage.jsx
    │   │   ├── UserProfilePage.jsx
    │   │   └── admin/
    │   │       ├── AdminDashboard.jsx
    │   │       ├── AdminUsers.jsx
    │   │       ├── AdminCourses.jsx
    │   │       ├── AdminChallenges.jsx
    │   │       ├── AdminCompetitions.jsx
    │   │       ├── AdminProjects.jsx
    │   │       ├── AdminFreelancer.jsx
    │   │       ├── AdminGroups.jsx
    │   │       ├── AdminSettings.jsx
    │   │       ├── AdminLab.jsx
    │   │       ├── AdminBadges.jsx
    │   │       └── AdminActivityLog.jsx
    │   └── components/
    │       ├── layout/            ← Navbar, Footer, Layout
    │       ├── auth/              ← ProtectedRoute, PrivateRoute
    │       ├── ctf/
    │       ├── course/
    │       └── common/
    └── vite.config.js
```

---

## نقاط API الرئيسية

| المسار | الطريقة | الوصف |
|--------|---------|-------|
| `/api/token/` | POST | تسجيل الدخول (يُعيد access + refresh tokens) |
| `/api/token/refresh/` | POST | تجديد رمز الوصول |
| `/api/users/register/` | POST | تسجيل مستخدم جديد |
| `/api/users/profile/` | GET/PUT | عرض وتعديل الملف الشخصي |
| `/api/users/leaderboard/` | GET | لوحة الصدارة |
| `/api/ctf/` | GET/POST | قائمة/إنشاء تحديات CTF |
| `/api/ctf/{id}/submit_flag/` | POST | إرسال العلم |
| `/api/ctf/categories/` | GET/POST | تصنيفات CTF |
| `/api/ctf/competitions/` | GET/POST | المسابقات |
| `/api/courses/` | GET/POST | قائمة/إنشاء دورات |
| `/api/courses/{id}/enroll/` | POST | التسجيل في دورة |
| `/api/projects/` | GET/POST | المشاريع |
| `/api/freelancer/tasks/` | GET/POST | مهام العمل الحر |
| `/api/freelancer/tasks/{id}/apply/` | POST | التقدم لمهمة |
| `/api/lab/` | GET/POST | تحديات المختبر |
| `/api/teams/` | GET/POST | الفِرق |
| `/api/badges/` | GET/POST | الشارات |
| `/api/notifications/` | GET | الإشعارات |
| `/api/settings/` | GET/PUT | إعدادات المنصة |
| `/api/activity-log/` | GET | سجل النشاطات |

---

## إعداد حساب المدير (Admin)

### الطريقة 1: SQL مباشر (موصى به عند الإعداد الأولي)
```sql
-- كلمة المرور الافتراضية: Admin@249shadow
-- قم بتغييرها فور تسجيل الدخول!
INSERT IGNORE INTO users (username, email, password, first_name, last_name, is_active, is_staff, is_superuser, ctf_score, created_at)
VALUES ('admin', 'admin@249shadow.com', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin', '249Shadow', 1, 1, 1, 0, NOW());
```

### الطريقة 2: سكريبت PHP
```bash
# انتقل لمجلد API
cd backend/public/api

# إنشاء بمعلومات افتراضية
php create_admin.php

# إنشاء بمعلومات مخصصة
php create_admin.php myusername admin@mysite.com MyStr0ngP@ss!

# احذف الملف بعد الاستخدام!
rm create_admin.php
```

**بيانات الدخول الافتراضية:**
- رابط لوحة الإدارة: `/admin`
- اسم المستخدم: `admin`
- كلمة المرور: `Admin@249shadow`

> ⚠️ **غيّر كلمة المرور فور أول تسجيل دخول!**

---

## التشغيل المحلي (Local)

### Backend
```bash
cp backend/.env.example backend/.env
# عدّل backend/public/api/config.php ببيانات قاعدة البيانات
mysql -u USER -p DATABASE < backend/schema.sql
php -S 0.0.0.0:8080 -t backend/public
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

---

## النشر على Plesk

### 1. رفع الملفات
```bash
# استخرج plesk_deploy.zip على السيرفر
unzip plesk_deploy.zip -d /var/www/vhosts/yourdomain.com/httpdocs/
```

### 2. إعداد قاعدة البيانات
```bash
mysql -u DB_USER -p DB_NAME < schema.sql
```

### 3. ضبط الإعدادات
عدّل `backend/public/api/config.php`:
```php
$_ENV['DB_HOST']      = 'localhost';
$_ENV['DB_NAME']      = 'your_db_name';
$_ENV['DB_USER']      = 'your_db_user';
$_ENV['DB_PASS']      = 'your_db_password';
$_ENV['JWT_SECRET']   = 'your_random_64_char_secret';
$_ENV['CORS_ORIGINS'] = 'https://yourdomain.com';
$_ENV['FRONTEND_URL'] = 'https://yourdomain.com';
```

### 4. إعداد Apache (.htaccess)
الملف موجود في `backend/public/.htaccess` — لا حاجة لتعديله.

### 5. إنشاء المدير
```bash
cd /path/to/backend/public/api
php create_admin.php admin admin@yourdomain.com YourP@ssword!
rm create_admin.php
```

---

## متغيرات البيئة (config.php)

| المتغير | الوصف | مثال |
|---------|-------|------|
| `DB_HOST` | مضيف قاعدة البيانات | `localhost` |
| `DB_PORT` | منفذ MySQL | `3306` |
| `DB_NAME` | اسم قاعدة البيانات | `shadow249` |
| `DB_USER` | مستخدم قاعدة البيانات | `root` |
| `DB_PASS` | كلمة مرور قاعدة البيانات | — |
| `JWT_SECRET` | سر JWT (64+ حرف) | `openssl rand -hex 64` |
| `CORS_ORIGINS` | النطاقات المسموحة | `https://yourdomain.com` |
| `FRONTEND_URL` | رابط الواجهة الأمامية | `https://yourdomain.com` |
| `APP_DEBUG` | وضع التصحيح | `false` |
| `MAIL_FROM` | بريد الإرسال | `noreply@yourdomain.com` |
| `SITE_NAME` | اسم المنصة | `249Shadow` |

---

## جداول قاعدة البيانات

| الجدول | الوصف |
|--------|-------|
| `users` | المستخدمون (يشمل is_staff, is_superuser) |
| `groups` | المجموعات والصلاحيات |
| `ctf_challenges` | تحديات CTF |
| `ctf_categories` | تصنيفات CTF |
| `ctf_solves` | حلول التحديات |
| `ctf_attempts` | محاولات التحديات |
| `ctf_competitions` | المسابقات |
| `ctf_teams` | الفِرق |
| `ctf_team_members` | أعضاء الفِرق |
| `courses` | الدورات التعليمية |
| `chapters` | فصول الدورات |
| `lessons` | دروس الفصول |
| `enrollments` | تسجيلات الدورات |
| `lab_challenges` | تحديات المختبر |
| `projects` | المشاريع |
| `freelancer_tasks` | مهام العمل الحر |
| `freelancer_applications` | طلبات المهام |
| `badges` | الشارات |
| `user_badges` | شارات المستخدمين |
| `course_comments` | تعليقات الدورات |
| `notifications` | الإشعارات |
| `activity_log` | سجل النشاطات |
| `site_settings` | إعدادات المنصة |

---

## نظام المصادقة

- يستخدم **JWT** مع رمزَين: `access` (صالح ساعة) و`refresh`
- الـ `access` يُرسَل في رأس `Authorization: Bearer <token>`
- عند انتهاء الـ `access`، يُجدَّد تلقائياً عبر `/api/token/refresh/`
- المستخدم `is_superuser=1` له صلاحيات كاملة على لوحة الإدارة
- المستخدم `is_staff=1` له صلاحيات إدارية جزئية

---

## الأمان

- كلمات المرور مشفّرة بـ `bcrypt` عبر `password_hash()`
- رموز JWT محمية بـ HMAC-SHA256
- مدخلات المستخدم مُعالَجة بـ PDO Prepared Statements
- CORS مُقيّد بالنطاقات المحددة في `config.php`
- وضع التصحيح (`APP_DEBUG`) مُعطَّل في الإنتاج

---

## الميزات المخططة

- [ ] نظام OAuth (Google / GitHub)
- [ ] إشعارات فورية عبر WebSockets
- [ ] نظام بحث متقدم
- [ ] دعم رفع ملفات الدورات
- [ ] تقارير وتحليلات متقدمة للوحة الإدارة

---

*249Shadow Platform — جميع الحقوق محفوظة © 2025*
