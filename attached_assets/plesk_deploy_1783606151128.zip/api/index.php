<?php
declare(strict_types=1);

// ─── Bootstrap ───────────────────────────────────────────────────────────────
require_once __DIR__ . '/config.php';

// ─── Autoload src classes ─────────────────────────────────────────────────────
$srcDir = __DIR__ . '/src';
foreach (glob($srcDir . '/*.php') as $f)            require_once $f;
foreach (glob($srcDir . '/controllers/*.php') as $f) require_once $f;

// ─── CORS ─────────────────────────────────────────────────────────────────────
$origin  = $_SERVER['HTTP_ORIGIN'] ?? '*';
$allowed = array_filter(
    array_map('trim', explode(',', $_ENV['CORS_ORIGINS'] ?? '*'))
);
if (in_array('*', $allowed) || in_array($origin, $allowed)) {
    header("Access-Control-Allow-Origin: $origin");
} else {
    header('Access-Control-Allow-Origin: ' . ($_ENV['FRONTEND_URL'] ?? '*'));
}
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ─── Router ───────────────────────────────────────────────────────────────────
$method = strtoupper($_SERVER['REQUEST_METHOD']);

// Strip /api prefix and parse segments
$uri   = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri   = preg_replace('#^/api#', '', $uri);
$uri   = rtrim($uri, '/') ?: '/';
$parts = explode('/', ltrim($uri, '/'));

$seg0 = $parts[0] ?? '';
$seg1 = $parts[1] ?? '';
$seg2 = $parts[2] ?? '';
$seg3 = $parts[3] ?? '';
$seg4 = $parts[4] ?? '';

$id  = is_numeric($seg1) ? (int)$seg1 : null;
$id2 = is_numeric($seg3) ? (int)$seg3 : null;

// ─── Route Definitions ────────────────────────────────────────────────────────
try {
    // --- AUTH ---
    if ($seg0 === 'token' && $seg1 === '') {
        if ($method === 'POST') AuthController::login();

    } elseif ($seg0 === 'token' && $seg1 === 'refresh') {
        if ($method === 'POST') AuthController::refresh();

    } elseif ($seg0 === 'users' && $seg1 === 'register') {
        if ($method === 'POST') AuthController::register();

    // --- USERS ---
    } elseif ($seg0 === 'users' && $seg1 === 'profile') {
        match($method) {
            'GET'          => UserController::profile(),
            'PUT', 'PATCH' => UserController::updateProfile(),
            default        => Response::error('Method not allowed', 405),
        };

    } elseif ($seg0 === 'users' && $seg1 === 'leaderboard') {
        if ($method === 'GET') UserController::leaderboard();

    } elseif ($seg0 === 'users' && $seg1 === 'stats') {
        if ($method === 'GET') UserController::stats();

    } elseif ($seg0 === 'users' && $id !== null) {
        match($method) {
            'PUT', 'PATCH' => UserController::update($id),
            'DELETE'       => UserController::delete($id),
            default        => Response::error('Method not allowed', 405),
        };

    } elseif ($seg0 === 'users' && $seg1 === '') {
        match($method) {
            'GET'   => UserController::list(),
            'POST'  => UserController::create(),
            default => Response::error('Method not allowed', 405),
        };

    // --- GROUPS ---
    } elseif ($seg0 === 'groups') {
        if ($id !== null && $method === 'DELETE') {
            UserController::deleteGroup($id);
        } else {
            match($method) {
                'GET'   => UserController::groups(),
                'POST'  => UserController::createGroup(),
                default => Response::error('Method not allowed', 405),
            };
        }

    // --- CTF CATEGORIES ---
    } elseif ($seg0 === 'ctf' && $seg1 === 'categories') {
        if ($id2 !== null && $method === 'DELETE') {
            CtfController::deleteCategory($id2);
        } else {
            match($method) {
                'GET'   => CtfController::listCategories(),
                'POST'  => CtfController::createCategory(),
                default => Response::error('Method not allowed', 405),
            };
        }

    // --- CTF COMPETITIONS ---
    } elseif ($seg0 === 'ctf' && $seg1 === 'competitions') {
        if ($id2 !== null) {
            match($method) {
                'PUT', 'PATCH' => CtfController::updateCompetition($id2),
                'DELETE'       => CtfController::deleteCompetition($id2),
                default        => Response::error('Method not allowed', 405),
            };
        } else {
            match($method) {
                'GET'   => CtfController::listCompetitions(),
                'POST'  => CtfController::createCompetition(),
                default => Response::error('Method not allowed', 405),
            };
        }

    // --- CTF CHALLENGES ---
    } elseif ($seg0 === 'ctf' && $id !== null && $seg2 === 'submit_flag') {
        if ($method === 'POST') CtfController::submitFlag($id);

    } elseif ($seg0 === 'ctf' && $id !== null) {
        match($method) {
            'GET'          => CtfController::getChallenge($id),
            'PUT', 'PATCH' => CtfController::updateChallenge($id),
            'DELETE'       => CtfController::deleteChallenge($id),
            default        => Response::error('Method not allowed', 405),
        };

    } elseif ($seg0 === 'ctf' && $seg1 === '') {
        match($method) {
            'GET'   => CtfController::listChallenges(),
            'POST'  => CtfController::createChallenge(),
            default => Response::error('Method not allowed', 405),
        };

    // --- COURSES CHAPTERS & LESSONS ---
    } elseif ($seg0 === 'courses' && $id !== null && $seg2 === 'chapters') {
        if ($id2 !== null && $seg4 === '') {
            match($method) {
                'PUT', 'PATCH' => CourseController::updateChapter($id2),
                'DELETE'       => CourseController::deleteChapter($id2),
                default        => Response::error('Method not allowed', 405),
            };
        } else {
            match($method) {
                'GET'   => CourseController::chapters($id),
                'POST'  => CourseController::createChapter($id),
                default => Response::error('Method not allowed', 405),
            };
        }

    } elseif ($seg0 === 'chapters' && $id !== null && $seg2 === 'lessons') {
        match($method) {
            'POST'  => CourseController::createLesson($id),
            default => Response::error('Method not allowed', 405),
        };

    } elseif ($seg0 === 'lessons' && $id !== null) {
        match($method) {
            'PUT', 'PATCH' => CourseController::updateLesson($id),
            'DELETE'       => CourseController::deleteLesson($id),
            default        => Response::error('Method not allowed', 405),
        };

    // --- COURSES ---
    } elseif ($seg0 === 'courses' && $id !== null && $seg2 === 'enroll') {
        if ($method === 'POST') CourseController::enroll($id);

    } elseif ($seg0 === 'courses' && $id !== null) {
        match($method) {
            'GET'          => CourseController::get($id),
            'PUT', 'PATCH' => CourseController::update($id),
            'DELETE'       => CourseController::delete($id),
            default        => Response::error('Method not allowed', 405),
        };

    } elseif ($seg0 === 'courses' && $seg1 === '') {
        match($method) {
            'GET'   => CourseController::list(),
            'POST'  => CourseController::create(),
            default => Response::error('Method not allowed', 405),
        };

    // --- PROJECTS ---
    } elseif ($seg0 === 'projects' && $id !== null) {
        match($method) {
            'GET'          => ProjectController::get($id),
            'PUT', 'PATCH' => ProjectController::update($id),
            'DELETE'       => ProjectController::delete($id),
            default        => Response::error('Method not allowed', 405),
        };

    } elseif ($seg0 === 'projects' && $seg1 === '') {
        match($method) {
            'GET'   => ProjectController::list(),
            'POST'  => ProjectController::create(),
            default => Response::error('Method not allowed', 405),
        };

    // --- LAB ---
    } elseif ($seg0 === 'lab' && $id !== null) {
        match($method) {
            'GET'          => LabController::get($id),
            'PUT', 'PATCH' => LabController::update($id),
            'DELETE'       => LabController::delete($id),
            default        => Response::error('Method not allowed', 405),
        };

    } elseif ($seg0 === 'lab' && $seg1 === '') {
        match($method) {
            'GET'   => LabController::list(),
            'POST'  => LabController::create(),
            default => Response::error('Method not allowed', 405),
        };

    // --- FREELANCER APPLICATIONS ---
    } elseif ($seg0 === 'freelancer' && $seg1 === 'applications') {
        if ($id2 !== null && $method === 'DELETE') {
            FreelancerController::deleteApplication($id2);
        } else {
            match($method) {
                'GET'   => FreelancerController::listApplications(),
                default => Response::error('Method not allowed', 405),
            };
        }

    } elseif ($seg0 === 'freelancer' && $seg1 === 'tasks' && $id2 !== null && $seg4 === 'apply') {
        if ($method === 'POST') FreelancerController::apply($id2);

    // --- FREELANCER TASKS ---
    } elseif ($seg0 === 'freelancer' && $seg1 === 'tasks' && $id2 !== null) {
        match($method) {
            'GET'          => FreelancerController::getTask($id2),
            'PUT', 'PATCH' => FreelancerController::updateTask($id2),
            'DELETE'       => FreelancerController::deleteTask($id2),
            default        => Response::error('Method not allowed', 405),
        };

    } elseif ($seg0 === 'freelancer' && ($seg1 === 'tasks' || $seg1 === '')) {
        match($method) {
            'GET'   => FreelancerController::listTasks(),
            'POST'  => FreelancerController::createTask(),
            default => Response::error('Method not allowed', 405),
        };

    // --- SETTINGS ---
    } elseif ($seg0 === 'settings') {
        match($method) {
            'GET'                    => SettingsController::get(),
            'PUT', 'PATCH', 'POST'   => SettingsController::update(),
            default                  => Response::error('Method not allowed', 405),
        };

    } elseif ($seg0 === 'latest') {
        if ($method === 'GET') SettingsController::latestContent();

    // --- BADGES ---
    } elseif ($seg0 === 'badges' && $seg1 === 'mine') {
        if ($method === 'GET') BadgeController::myBadges();

    } elseif ($seg0 === 'badges' && $id !== null && $method === 'DELETE') {
        BadgeController::delete($id);

    } elseif ($seg0 === 'badges') {
        match($method) {
            'GET'   => BadgeController::listAll(),
            'POST'  => BadgeController::create(),
            default => Response::error('Method not allowed', 405),
        };

    // --- COMMENTS ---
    } elseif ($seg0 === 'courses' && $id !== null && $seg2 === 'comments') {
        match($method) {
            'GET'   => CommentController::listByCourse($id),
            'POST'  => CommentController::create($id),
            default => Response::error('Method not allowed', 405),
        };

    } elseif ($seg0 === 'comments' && $id !== null && $method === 'DELETE') {
        CommentController::delete($id);

    // --- CTF TEAMS ---
    } elseif ($seg0 === 'teams' && $seg1 === 'my') {
        if ($method === 'GET') TeamController::myTeam();

    } elseif ($seg0 === 'teams' && $seg1 === 'join') {
        if ($method === 'POST') TeamController::join();

    } elseif ($seg0 === 'teams' && $seg1 === 'leave') {
        if ($method === 'POST') TeamController::leave();

    } elseif ($seg0 === 'teams' && $id !== null && $method === 'DELETE') {
        TeamController::deleteTeam($id);

    } elseif ($seg0 === 'teams' && $id !== null) {
        if ($method === 'GET') TeamController::get($id);

    } elseif ($seg0 === 'teams') {
        match($method) {
            'GET'   => TeamController::list(),
            'POST'  => TeamController::create(),
            default => Response::error('Method not allowed', 405),
        };

    // --- NOTIFICATIONS ---
    } elseif ($seg0 === 'notifications' && $seg1 === 'read-all') {
        if ($method === 'POST') NotificationController::markAllRead();

    } elseif ($seg0 === 'notifications' && $seg1 === 'broadcast') {
        if ($method === 'POST') NotificationController::broadcast();

    } elseif ($seg0 === 'notifications' && $id !== null && $seg2 === 'read') {
        if ($method === 'POST') NotificationController::markRead($id);

    } elseif ($seg0 === 'notifications' && $id !== null && $method === 'DELETE') {
        NotificationController::delete($id);

    } elseif ($seg0 === 'notifications') {
        if ($method === 'GET') NotificationController::myNotifications();

    // --- ACTIVITY LOG ---
    } elseif ($seg0 === 'activity-log' && $seg1 === 'clear') {
        if ($method === 'DELETE') ActivityLog::clear();

    } elseif ($seg0 === 'activity-log') {
        if ($method === 'GET') ActivityLog::list();

    // --- HEALTH ---
    } elseif ($seg0 === 'health' || $seg0 === '') {
        Response::json(['status' => 'ok', 'platform' => '249Shadow', 'version' => '2.0']);

    } else {
        Response::notFound("Endpoint /$seg0 not found");
    }

} catch (Throwable $e) {
    $debug = ($_ENV['APP_DEBUG'] ?? 'false') === 'true';
    Response::json(
        $debug
            ? ['detail' => $e->getMessage(), 'trace' => $e->getTraceAsString()]
            : ['detail' => 'Internal server error'],
        500
    );
}
