<?php
/**
 * 249Shadow — Admin Account Creator / Password Reset
 *
 * Run via CLI:     php create_admin.php [username] [email] [password]
 * Run via browser: https://yourdomain.com/api/create_admin.php
 *
 * ⚠️  DELETE this file after use!
 */
declare(strict_types=1);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/src/DB.php';

$isCli     = PHP_SAPI === 'cli';
$username  = $isCli ? ($argv[1] ?? 'admin')              : ($_GET['username'] ?? 'admin');
$email     = $isCli ? ($argv[2] ?? 'admin@249shadow.com') : ($_GET['email']    ?? 'admin@249shadow.com');
$password  = $isCli ? ($argv[3] ?? 'Admin@249shadow')     : ($_GET['password'] ?? 'Admin@249shadow');

if (!$isCli) {
    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="utf-8">
    <title>249Shadow — إنشاء حساب الأدمن</title>
    <style>body{font-family:monospace;background:#111;color:#0f0;padding:2rem;direction:rtl}
    .ok{color:#0f0}.err{color:#f00}.warn{color:#ff0}
    pre{background:#222;padding:1rem;border-radius:8px}
    </style></head><body><h2>🛡️ 249Shadow — أداة إنشاء الأدمن</h2><pre>';
}

function out(string $msg, string $type = 'ok'): void {
    global $isCli;
    if ($isCli) {
        echo $msg . PHP_EOL;
    } else {
        $color = match($type) { 'err' => '#f00', 'warn' => '#ff0', default => '#0f0' };
        echo "<span style=\"color:$color\">" . htmlspecialchars($msg) . "</span>\n";
    }
}

if (strlen($password) < 8) {
    out('❌ كلمة المرور يجب أن تكون 8 أحرف على الأقل.', 'err');
    exit(1);
}

try {
    $exists = DB::fetchOne(
        'SELECT id, username FROM users WHERE username = ? OR email = ?',
        [$username, $email]
    );

    $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

    if ($exists) {
        // Reset password for existing user
        DB::update('users',
            ['password' => $hash, 'is_active' => 1, 'is_staff' => 1, 'is_superuser' => 1],
            'id = ?',
            [$exists['id']]
        );
        out("✅ تم تحديث كلمة مرور المستخدم الموجود: {$exists['username']} (ID: {$exists['id']})");
        out("   البريد الإلكتروني : $email");
        out("   كلمة المرور الجديدة: $password");
        out("   الهاش: $hash", 'warn');
    } else {
        // Create new admin
        $id = DB::insert('users', [
            'username'     => $username,
            'email'        => $email,
            'password'     => $hash,
            'first_name'   => 'Admin',
            'last_name'    => '249Shadow',
            'is_active'    => 1,
            'is_staff'     => 1,
            'is_superuser' => 1,
            'ctf_score'    => 0,
            'created_at'   => date('Y-m-d H:i:s'),
        ]);
        out("✅ تم إنشاء حساب الأدمن بنجاح!");
        out("   ID           : $id");
        out("   اسم المستخدم  : $username");
        out("   البريد        : $email");
        out("   كلمة المرور   : $password");
    }

    out('');
    out('⚠️  احذف هذا الملف بعد الانتهاء: rm create_admin.php', 'warn');

} catch (Throwable $e) {
    out('❌ خطأ: ' . $e->getMessage(), 'err');
    out('تأكد من إعدادات قاعدة البيانات في config.php وأن الجداول مُنشأة من schema.sql', 'warn');
}

if (!$isCli) {
    echo '</pre></body></html>';
}
