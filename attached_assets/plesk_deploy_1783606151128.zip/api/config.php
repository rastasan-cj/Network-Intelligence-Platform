<?php
declare(strict_types=1);

// ─── Application ──────────────────────────────────────────────────────────────
$_ENV['APP_DEBUG'] = 'false';
$_ENV['APP_ENV']   = 'production';

// ─── JWT Secret ───────────────────────────────────────────────────────────────
// Generate a strong secret: openssl rand -hex 64
$_ENV['JWT_SECRET'] = 'CHANGE_ME_USE_STRONG_RANDOM_SECRET_64_CHARS_MINIMUM';

// ─── Database ─────────────────────────────────────────────────────────────────
$_ENV['DB_HOST'] = 'localhost';
$_ENV['DB_PORT'] = '3306';
$_ENV['DB_NAME'] = 'shadow249';
$_ENV['DB_USER'] = 'Rastasan';
$_ENV['DB_PASS'] = 'Rasta61@kincjrap';

// ─── CORS / Frontend URL ──────────────────────────────────────────────────────
$_ENV['CORS_ORIGINS']   = 'https://learn.249shadow.org';
$_ENV['FRONTEND_URL']   = 'https://learn.249shadow.org';

// ─── Uploads ──────────────────────────────────────────────────────────────────
$_ENV['UPLOAD_MAX_SIZE'] = '20971520';
