-- 249Shadow Platform — MySQL / MariaDB Schema
-- Run once on your Plesk database: mysql -u USER -p DATABASE < schema.sql

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ─── Users ────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `users` (
    `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `username`     VARCHAR(150) NOT NULL UNIQUE,
    `email`        VARCHAR(254) NOT NULL UNIQUE,
    `password`     VARCHAR(255) NOT NULL,
    `first_name`   VARCHAR(100) DEFAULT '',
    `last_name`    VARCHAR(100) DEFAULT '',
    `bio`          TEXT DEFAULT NULL,
    `avatar_url`   VARCHAR(500) DEFAULT NULL,
    `ctf_score`    INT UNSIGNED DEFAULT 0,
    `is_active`    TINYINT(1) NOT NULL DEFAULT 1,
    `is_staff`     TINYINT(1) NOT NULL DEFAULT 0,
    `is_superuser` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX (`ctf_score`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── Groups ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `groups` (
    `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name`        VARCHAR(150) NOT NULL UNIQUE,
    `permissions` TEXT DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── CTF Categories ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `ctf_categories` (
    `id`   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── CTF Challenges ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `ctf_challenges` (
    `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `title`       VARCHAR(255) NOT NULL,
    `category_id` INT UNSIGNED DEFAULT NULL,
    `points`      INT UNSIGNED NOT NULL DEFAULT 100,
    `difficulty`  ENUM('Easy','Medium','Hard') NOT NULL DEFAULT 'Medium',
    `description` TEXT DEFAULT NULL,
    `flag`        VARCHAR(255) NOT NULL,
    `file_url`    VARCHAR(500) DEFAULT NULL,
    `is_active`   TINYINT(1) NOT NULL DEFAULT 1,
    `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`category_id`) REFERENCES `ctf_categories`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── CTF Solves ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `ctf_solves` (
    `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`      INT UNSIGNED NOT NULL,
    `challenge_id` INT UNSIGNED NOT NULL,
    `solved_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_user_challenge` (`user_id`, `challenge_id`),
    FOREIGN KEY (`user_id`)      REFERENCES `users`(`id`)          ON DELETE CASCADE,
    FOREIGN KEY (`challenge_id`) REFERENCES `ctf_challenges`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── CTF Attempts ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `ctf_attempts` (
    `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`      INT UNSIGNED NOT NULL,
    `challenge_id` INT UNSIGNED NOT NULL,
    `flag_tried`   VARCHAR(255) DEFAULT '',
    `created_at`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`)      REFERENCES `users`(`id`)          ON DELETE CASCADE,
    FOREIGN KEY (`challenge_id`) REFERENCES `ctf_challenges`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── CTF Competitions ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `ctf_competitions` (
    `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name`        VARCHAR(255) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `reg_start`   DATETIME DEFAULT NULL,
    `reg_end`     DATETIME DEFAULT NULL,
    `event_date`  DATETIME DEFAULT NULL,
    `rules`       TEXT DEFAULT NULL,
    `is_active`   TINYINT(1) NOT NULL DEFAULT 1,
    `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Courses ──────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `courses` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `title`           VARCHAR(255) NOT NULL,
    `description`     TEXT DEFAULT NULL,
    `instructor_name` VARCHAR(200) DEFAULT '',
    `instructor_bio`  TEXT DEFAULT NULL,
    `price`           DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `thumbnail_url`   VARCHAR(500) DEFAULT NULL,
    `is_published`    TINYINT(1) NOT NULL DEFAULT 0,
    `created_at`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Chapters ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `chapters` (
    `id`        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `course_id` INT UNSIGNED NOT NULL,
    `title`     VARCHAR(255) NOT NULL,
    `order_num` INT NOT NULL DEFAULT 0,
    FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Lessons ──────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `lessons` (
    `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `chapter_id`  INT UNSIGNED NOT NULL,
    `title`       VARCHAR(255) NOT NULL,
    `video_url`   VARCHAR(500) DEFAULT '',
    `file_url`    VARCHAR(500) DEFAULT NULL,
    `duration`    VARCHAR(20) DEFAULT '',
    `order_num`   INT NOT NULL DEFAULT 0,
    `is_free`     TINYINT(1) NOT NULL DEFAULT 0,
    FOREIGN KEY (`chapter_id`) REFERENCES `chapters`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Enrollments ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `enrollments` (
    `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`     INT UNSIGNED NOT NULL,
    `course_id`   INT UNSIGNED NOT NULL,
    `enrolled_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_enrollment` (`user_id`, `course_id`),
    FOREIGN KEY (`user_id`)   REFERENCES `users`(`id`)   ON DELETE CASCADE,
    FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Projects ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `projects` (
    `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `title`       VARCHAR(255) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `category`    VARCHAR(100) DEFAULT '',
    `type`        VARCHAR(100) DEFAULT '',
    `slug`        VARCHAR(200) DEFAULT '',
    `demo_url`    VARCHAR(500) DEFAULT '',
    `image_url`   VARCHAR(500) DEFAULT NULL,
    `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Lab Challenges ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `lab_challenges` (
    `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `title`       VARCHAR(255) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `category`    VARCHAR(100) DEFAULT '',
    `difficulty`  ENUM('Easy','Medium','Hard') NOT NULL DEFAULT 'Easy',
    `points`      INT UNSIGNED DEFAULT 0,
    `file_url`    VARCHAR(500) DEFAULT NULL,
    `is_active`   TINYINT(1) NOT NULL DEFAULT 1,
    `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Freelancer Tasks ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `freelancer_tasks` (
    `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `title`       VARCHAR(255) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `skills`      VARCHAR(500) DEFAULT '',
    `reward`      VARCHAR(255) DEFAULT '',
    `is_money`    TINYINT(1) NOT NULL DEFAULT 0,
    `is_active`   TINYINT(1) NOT NULL DEFAULT 1,
    `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Freelancer Applications ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `freelancer_applications` (
    `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`    INT UNSIGNED NOT NULL,
    `task_id`    INT UNSIGNED NOT NULL,
    `contact`    VARCHAR(255) DEFAULT '',
    `message`    TEXT DEFAULT NULL,
    `applied_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`)           ON DELETE CASCADE,
    FOREIGN KEY (`task_id`) REFERENCES `freelancer_tasks`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Site Settings ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `site_settings` (
    `id`                    INT UNSIGNED PRIMARY KEY DEFAULT 1,
    `site_name`             VARCHAR(255) NOT NULL DEFAULT '249Shadow',
    `site_description`      TEXT DEFAULT NULL,
    `contact_email`         VARCHAR(254) DEFAULT '',
    `maintenance_mode`      TINYINT(1) NOT NULL DEFAULT 0,
    `ctf_enabled`           TINYINT(1) NOT NULL DEFAULT 1,
    `registration_enabled`  TINYINT(1) NOT NULL DEFAULT 1,
    `allow_registration`    TINYINT(1) NOT NULL DEFAULT 1,
    `max_flag_attempts`     INT NOT NULL DEFAULT 10
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default settings row
INSERT IGNORE INTO `site_settings` (`id`, `site_name`, `site_description`, `contact_email`)
VALUES (1, '249Shadow', 'Cybersecurity Learning Platform', 'admin@249shadow.com');

SET FOREIGN_KEY_CHECKS = 1;

-- ─── Badges ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `badges` (
    `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name`            VARCHAR(150) NOT NULL,
    `icon`            VARCHAR(20) DEFAULT '🏅',
    `description`     TEXT DEFAULT NULL,
    `condition_type`  VARCHAR(50) NOT NULL DEFAULT 'manual',
    `condition_value` INT NOT NULL DEFAULT 0,
    `created_at`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── User Badges ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `user_badges` (
    `id`        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`   INT UNSIGNED NOT NULL,
    `badge_id`  INT UNSIGNED NOT NULL,
    `earned_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_user_badge` (`user_id`, `badge_id`),
    FOREIGN KEY (`user_id`)  REFERENCES `users`(`id`)  ON DELETE CASCADE,
    FOREIGN KEY (`badge_id`) REFERENCES `badges`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Course Comments ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `course_comments` (
    `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `course_id`  INT UNSIGNED NOT NULL,
    `user_id`    INT UNSIGNED NOT NULL,
    `comment`    TEXT NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_id`)   REFERENCES `users`(`id`)   ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── CTF Teams ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `ctf_teams` (
    `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name`        VARCHAR(150) NOT NULL UNIQUE,
    `description` TEXT DEFAULT NULL,
    `invite_code` VARCHAR(20) NOT NULL UNIQUE,
    `created_by`  INT UNSIGNED NOT NULL,
    `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── CTF Team Members ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `ctf_team_members` (
    `id`        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `team_id`   INT UNSIGNED NOT NULL,
    `user_id`   INT UNSIGNED NOT NULL,
    `role`      ENUM('leader','member') NOT NULL DEFAULT 'member',
    `joined_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_team_member` (`user_id`),
    FOREIGN KEY (`team_id`) REFERENCES `ctf_teams`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`)    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Activity Log ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `activity_log` (
    `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`    INT UNSIGNED DEFAULT NULL,
    `action`     VARCHAR(100) NOT NULL,
    `details`    TEXT DEFAULT NULL,
    `ip_address` VARCHAR(45) DEFAULT '',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX (`user_id`),
    INDEX (`action`),
    INDEX (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Notifications ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `notifications` (
    `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id`    INT UNSIGNED NOT NULL,
    `title`      VARCHAR(255) NOT NULL,
    `message`    TEXT NOT NULL,
    `type`       VARCHAR(50) NOT NULL DEFAULT 'info',
    `is_read`    TINYINT(1) NOT NULL DEFAULT 0,
    `link`       VARCHAR(500) DEFAULT '',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX (`user_id`),
    INDEX (`is_read`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Seed Badges ──────────────────────────────────────────────────────────────
INSERT IGNORE INTO `badges` (`id`,`name`,`icon`,`description`,`condition_type`,`condition_value`) VALUES
(1, 'First Blood',    '🩸', 'Solved your first CTF challenge',   'ctf_solves',  1),
(2, 'Hacker',         '💻', 'Solved 5 CTF challenges',           'ctf_solves',  5),
(3, 'Elite Hacker',   '🔥', 'Solved 10 CTF challenges',          'ctf_solves', 10),
(4, 'Legend',         '🏆', 'Solved 25 CTF challenges',          'ctf_solves', 25),
(5, 'Student',        '🎓', 'Enrolled in your first course',     'enrollments', 1),
(6, 'Scholar',        '📚', 'Enrolled in 3 courses',             'enrollments', 3);

-- ─── Seed Admin User ──────────────────────────────────────────────────────────
-- Default admin: username=admin | email=admin@249shadow.com | password=Admin@249shadow
-- Hash = password_hash('Admin@249shadow', PASSWORD_BCRYPT, ['cost'=>12])
-- CHANGE THE PASSWORD IMMEDIATELY AFTER FIRST LOGIN
-- If admin already exists with wrong password, run:
--   UPDATE users SET password='$2b$12$8.uH1dDO3GVU4ibl6HRQxuO7UbblV77f.cnhAreZF07i6jwBIN9Za' WHERE username='admin';
INSERT IGNORE INTO `users`
    (`username`, `email`, `password`, `first_name`, `last_name`, `is_active`, `is_staff`, `is_superuser`, `ctf_score`, `created_at`)
VALUES
    ('admin', 'admin@249shadow.com',
     '$2b$12$8.uH1dDO3GVU4ibl6HRQxuO7UbblV77f.cnhAreZF07i6jwBIN9Za',
     'Admin', '249Shadow', 1, 1, 1, 0, NOW());
