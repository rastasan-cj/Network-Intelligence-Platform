<?php
declare(strict_types=1);

class Response
{
    public static function json(mixed $data, int $status = 200): void
    {
        http_response_code($status);
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    public static function error(string $message, int $status = 400): void
    {
        self::json(['detail' => $message], $status);
    }

    public static function notFound(string $message = 'Not found'): void
    {
        self::error($message, 404);
    }

    public static function unauthorized(string $message = 'Authentication required'): void
    {
        self::error($message, 401);
    }

    public static function forbidden(string $message = 'Permission denied'): void
    {
        self::error($message, 403);
    }

    public static function created(mixed $data): void
    {
        self::json($data, 201);
    }

    public static function noContent(): void
    {
        http_response_code(204);
        exit;
    }
}
