<?php
declare(strict_types=1);

class ActivityLog
{
    public static function log(int $userId, string $action, string $details = '', string $ip = ''): void
    {
        if ($ip === '') {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR']
               ?? $_SERVER['REMOTE_ADDR']
               ?? '';
            $ip = explode(',', $ip)[0];
            $ip = trim($ip);
        }
        try {
            DB::insert('activity_log', [
                'user_id'    => $userId,
                'action'     => $action,
                'details'    => $details,
                'ip_address' => substr($ip, 0, 45),
                'created_at' => date('Y-m-d H:i:s'),
            ]);
        } catch (Throwable) {
        }
    }

    public static function list(): void
    {
        Auth::requireAdmin();
        $limit  = min((int)($_GET['limit']  ?? 100), 500);
        $offset = (int)($_GET['offset'] ?? 0);
        $action = $_GET['action'] ?? '';
        $userId = isset($_GET['user_id']) ? (int)$_GET['user_id'] : null;

        $where = [];
        $params = [];
        if ($action) { $where[] = 'a.action = ?'; $params[] = $action; }
        if ($userId) { $where[] = 'a.user_id = ?'; $params[] = $userId; }

        $sql = 'SELECT a.*, u.username FROM activity_log a
                LEFT JOIN users u ON u.id = a.user_id'
             . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
             . ' ORDER BY a.created_at DESC LIMIT ? OFFSET ?';

        $params[] = $limit;
        $params[] = $offset;

        $rows = DB::fetchAll($sql, $params);
        Response::json($rows);
    }

    public static function clear(): void
    {
        Auth::requireAdmin();
        DB::query('DELETE FROM activity_log WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)');
        Response::json(['message' => 'Old logs cleared (older than 30 days)']);
    }
}
