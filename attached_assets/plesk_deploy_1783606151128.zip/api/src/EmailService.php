<?php
declare(strict_types=1);

class EmailService
{
    private static function getFrom(): array
    {
        return [
            'email' => $_ENV['MAIL_FROM'] ?? ('noreply@' . ($_ENV['MAIL_DOMAIN'] ?? 'example.com')),
            'name'  => $_ENV['MAIL_FROM_NAME'] ?? ($_ENV['SITE_NAME'] ?? '249Shadow'),
        ];
    }

    public static function send(string $toEmail, string $toName, string $subject, string $htmlBody): bool
    {
        $from = self::getFrom();

        $headers  = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "From: {$from['name']} <{$from['email']}>\r\n";
        $headers .= "Reply-To: {$from['email']}\r\n";
        $headers .= "X-Mailer: PHP/" . PHP_VERSION . "\r\n";

        $body = self::wrapHtml($from['name'], $htmlBody);

        return @mail($toEmail, $subject, $body, $headers);
    }

    private static function wrapHtml(string $siteName, string $content): string
    {
        return <<<HTML
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><style>
  body { font-family: Arial, sans-serif; background: #f4f4f4; margin: 0; padding: 20px; }
  .container { max-width: 600px; margin: 0 auto; background: #fff; border-radius: 10px; overflow: hidden; }
  .header { background: #1d4ed8; color: #fff; padding: 30px; text-align: center; }
  .body { padding: 30px; color: #333; line-height: 1.6; }
  .footer { background: #f9f9f9; padding: 20px; text-align: center; color: #999; font-size: 12px; }
  .btn { display: inline-block; background: #1d4ed8; color: #fff; padding: 12px 28px;
         border-radius: 6px; text-decoration: none; font-weight: bold; margin-top: 20px; }
</style></head>
<body>
  <div class="container">
    <div class="header"><h1>$siteName</h1></div>
    <div class="body">$content</div>
    <div class="footer">&copy; {$siteName}. All rights reserved.</div>
  </div>
</body>
</html>
HTML;
    }

    public static function sendWelcome(string $email, string $username): bool
    {
        $site = $_ENV['SITE_NAME'] ?? '249Shadow';
        $url  = $_ENV['FRONTEND_URL'] ?? '';
        return self::send($email, $username, "Welcome to $site!", <<<HTML
<h2>Welcome, $username! 🎉</h2>
<p>Your account has been created successfully on <strong>$site</strong>.</p>
<p>Start your cybersecurity journey today — explore courses, solve CTF challenges, and climb the leaderboard.</p>
<a href="$url" class="btn">Get Started</a>
HTML
        );
    }

    public static function sendCtfSolved(string $email, string $username, string $challengeTitle, int $points): bool
    {
        $site = $_ENV['SITE_NAME'] ?? '249Shadow';
        return self::send($email, $username, "🚩 Challenge Solved: $challengeTitle", <<<HTML
<h2>Congratulations, $username! 🏆</h2>
<p>You successfully solved the CTF challenge: <strong>$challengeTitle</strong></p>
<p>You earned <strong>+$points points</strong>. Keep going!</p>
HTML
        );
    }

    public static function sendNewCourse(string $email, string $username, string $courseTitle): bool
    {
        $site = $_ENV['SITE_NAME'] ?? '249Shadow';
        $url  = $_ENV['FRONTEND_URL'] ?? '';
        return self::send($email, $username, "🎓 New Course Available: $courseTitle", <<<HTML
<h2>New Course Alert!</h2>
<p>A new course has been published on $site: <strong>$courseTitle</strong></p>
<a href="$url/courses" class="btn">View Course</a>
HTML
        );
    }
}
