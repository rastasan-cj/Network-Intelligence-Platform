<?php
declare(strict_types=1);

class Auth
{
    private static ?array $currentUser = null;

    public static function getSecret(): string
    {
        return $_ENV['JWT_SECRET'] ?? 'change-me-in-production-use-strong-secret';
    }

    public static function attempt(): ?array
    {
        if (self::$currentUser !== null) {
            return self::$currentUser;
        }

        $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if (!str_starts_with($authHeader, 'Bearer ')) {
            return null;
        }

        $token = substr($authHeader, 7);
        try {
            $payload = JWT::decode($token, self::getSecret());
            $user = DB::fetchOne('SELECT * FROM users WHERE id = ?', [$payload['user_id']]);
            if ($user && (bool)$user['is_active']) {
                self::$currentUser = $user;
                return $user;
            }
        } catch (RuntimeException) {
            return null;
        }

        return null;
    }

    public static function require(): array
    {
        $user = self::attempt();
        if (!$user) {
            Response::unauthorized();
        }
        return $user;
    }

    public static function requireAdmin(): array
    {
        $user = self::require();
        if (!(bool)$user['is_staff']) {
            Response::forbidden('Admin access required');
        }
        return $user;
    }

    public static function hashPassword(string $plain): string
    {
        return password_hash($plain, PASSWORD_BCRYPT, ['cost' => 12]);
    }

    public static function verifyPassword(string $plain, string $hash): bool
    {
        return password_verify($plain, $hash);
    }

    public static function makeTokenPair(int $userId): array
    {
        $secret = self::getSecret();
        $access  = JWT::encode(['user_id' => $userId, 'type' => 'access'], $secret, 3600);
        $refresh = JWT::encodeRefresh(['user_id' => $userId, 'type' => 'refresh'], $secret);
        return ['access' => $access, 'refresh' => $refresh];
    }
}
