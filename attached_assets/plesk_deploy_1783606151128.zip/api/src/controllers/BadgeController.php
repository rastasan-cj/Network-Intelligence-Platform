<?php
declare(strict_types=1);

class BadgeController
{
    public static function listAll(): void
    {
        $badges = DB::fetchAll('SELECT * FROM badges ORDER BY id ASC');
        Response::json($badges);
    }

    public static function myBadges(): void
    {
        $user = Auth::require();
        $badges = DB::fetchAll(
            'SELECT b.*, ub.earned_at FROM badges b
             JOIN user_badges ub ON ub.badge_id = b.id
             WHERE ub.user_id = ?
             ORDER BY ub.earned_at DESC',
            [$user['id']]
        );
        Response::json($badges);
    }

    public static function userBadges(int $userId): void
    {
        $badges = DB::fetchAll(
            'SELECT b.*, ub.earned_at FROM badges b
             JOIN user_badges ub ON ub.badge_id = b.id
             WHERE ub.user_id = ?
             ORDER BY ub.earned_at DESC',
            [$userId]
        );
        Response::json($badges);
    }

    public static function create(): void
    {
        Auth::requireAdmin();
        $body = json_decode(file_get_contents('php://input'), true) ?? [];
        $name  = trim($body['name'] ?? '');
        $icon  = trim($body['icon'] ?? '🏅');
        $desc  = trim($body['description'] ?? '');
        $ctype = trim($body['condition_type'] ?? 'manual');
        $cval  = (int)($body['condition_value'] ?? 0);

        if (!$name) Response::error('Badge name is required');

        $id = DB::insert('badges', [
            'name'            => $name,
            'icon'            => $icon,
            'description'     => $desc,
            'condition_type'  => $ctype,
            'condition_value' => $cval,
            'created_at'      => date('Y-m-d H:i:s'),
        ]);
        Response::created(['id' => $id, 'name' => $name, 'icon' => $icon]);
    }

    public static function delete(int $id): void
    {
        Auth::requireAdmin();
        DB::query('DELETE FROM badges WHERE id = ?', [$id]);
        Response::noContent();
    }

    public static function award(int $userId, string $conditionType, int $value = 0): void
    {
        $badges = DB::fetchAll(
            'SELECT * FROM badges WHERE condition_type = ?',
            [$conditionType]
        );
        foreach ($badges as $badge) {
            if ($value >= $badge['condition_value']) {
                $exists = DB::fetchOne(
                    'SELECT id FROM user_badges WHERE user_id = ? AND badge_id = ?',
                    [$userId, $badge['id']]
                );
                if (!$exists) {
                    DB::insert('user_badges', [
                        'user_id'   => $userId,
                        'badge_id'  => $badge['id'],
                        'earned_at' => date('Y-m-d H:i:s'),
                    ]);
                    NotificationController::create(
                        $userId,
                        '🏅 New Badge Earned!',
                        "You earned the \"{$badge['name']}\" badge — {$badge['description']}",
                        'badge',
                        '/profile'
                    );
                }
            }
        }
    }
}
