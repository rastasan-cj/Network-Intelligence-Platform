<?php
declare(strict_types=1);

class ProjectController
{
    public static function list(): void
    {
        $rows = DB::fetchAll('SELECT * FROM projects ORDER BY id DESC');
        Response::json($rows);
    }

    public static function get(int $id): void
    {
        $row = DB::fetchOne('SELECT * FROM projects WHERE id = ?', [$id]);
        if (!$row) Response::notFound();
        Response::json($row);
    }

    public static function create(): void
    {
        Auth::requireAdmin();
        $body = self::parseInput();
        if (empty($body['title'])) Response::error('Title required');

        $imageUrl = self::handleFileUpload('image', 'projects');

        $id = DB::insert('projects', [
            'title'       => $body['title'],
            'description' => $body['description'] ?? '',
            'category'    => $body['category']    ?? '',
            'type'        => $body['type']         ?? '',
            'slug'        => $body['slug']         ?? '',
            'demo_url'    => $body['demo_url']     ?? '',
            'image_url'   => $imageUrl,
            'created_at'  => date('Y-m-d H:i:s'),
        ]);
        Response::created(DB::fetchOne('SELECT * FROM projects WHERE id = ?', [$id]));
    }

    public static function update(int $id): void
    {
        Auth::requireAdmin();
        $body = self::parseInput();
        $allowed = ['title', 'description', 'category', 'type', 'slug', 'demo_url'];
        $data = [];
        foreach ($allowed as $f) {
            if (array_key_exists($f, $body)) $data[$f] = $body[$f];
        }
        $img = self::handleFileUpload('image', 'projects');
        if ($img) $data['image_url'] = $img;

        if (!empty($data)) DB::update('projects', $data, 'id = ?', [$id]);
        $row = DB::fetchOne('SELECT * FROM projects WHERE id = ?', [$id]);
        if (!$row) Response::notFound();
        Response::json($row);
    }

    public static function delete(int $id): void
    {
        Auth::requireAdmin();
        DB::query('DELETE FROM projects WHERE id = ?', [$id]);
        Response::noContent();
    }

    private static function parseInput(): array
    {
        $ct = $_SERVER['CONTENT_TYPE'] ?? '';
        if (str_contains($ct, 'multipart/form-data')) return $_POST;
        return json_decode(file_get_contents('php://input'), true) ?? [];
    }

    private static function handleFileUpload(string $field, string $sub): ?string
    {
        if (empty($_FILES[$field]['tmp_name'])) return null;
        $dir = dirname(__DIR__, 2) . "/public/uploads/$sub/";
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        $ext  = pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION);
        $name = uniqid("{$sub}_", true) . '.' . $ext;
        move_uploaded_file($_FILES[$field]['tmp_name'], $dir . $name);
        return "/uploads/$sub/$name";
    }
}
