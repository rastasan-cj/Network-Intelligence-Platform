<?php
declare(strict_types=1);

class CtfController
{
    public static function listCategories(): void
    {
        $cats = DB::fetchAll('SELECT * FROM ctf_categories ORDER BY name');
        Response::json($cats);
    }

    public static function createCategory(): void
    {
        Auth::requireAdmin();
        $body = json_decode(file_get_contents('php://input'), true) ?? [];
        if (empty($body['name'])) Response::error('Category name required');
        $id = DB::insert('ctf_categories', ['name' => $body['name']]);
        Response::created(DB::fetchOne('SELECT * FROM ctf_categories WHERE id = ?', [$id]));
    }

    public static function deleteCategory(int $id): void
    {
        Auth::requireAdmin();
        DB::query('DELETE FROM ctf_categories WHERE id = ?', [$id]);
        Response::noContent();
    }

    public static function listChallenges(): void
    {
        $user = Auth::attempt();
        if ($user && (bool)$user['is_staff']) {
            $rows = DB::fetchAll(
                'SELECT c.*, cat.name as category_name FROM ctf_challenges c
                 LEFT JOIN ctf_categories cat ON cat.id = c.category_id ORDER BY c.id DESC'
            );
        } else {
            Auth::require();
            $rows = DB::fetchAll(
                'SELECT c.*, cat.name as category_name FROM ctf_challenges c
                 LEFT JOIN ctf_categories cat ON cat.id = c.category_id
                 WHERE c.is_active = 1 ORDER BY c.id DESC'
            );
        }
        Response::json($rows);
    }

    public static function getChallenge(int $id): void
    {
        $user = Auth::require();
        $extra = (bool)$user['is_staff'] ? '' : 'AND c.is_active = 1';
        $row = DB::fetchOne(
            "SELECT c.*, cat.name as category_name FROM ctf_challenges c
             LEFT JOIN ctf_categories cat ON cat.id = c.category_id
             WHERE c.id = ? $extra",
            [$id]
        );
        if (!$row) Response::notFound();

        if (!(bool)$user['is_staff']) unset($row['flag']);

        $solved = DB::fetchOne(
            'SELECT id FROM ctf_solves WHERE user_id = ? AND challenge_id = ?',
            [$user['id'], $id]
        );
        $row['is_solved'] = (bool)$solved;
        $row['solve_count'] = (int)DB::fetchOne(
            'SELECT COUNT(*) as c FROM ctf_solves WHERE challenge_id = ?', [$id]
        )['c'];

        Response::json($row);
    }

    public static function createChallenge(): void
    {
        Auth::requireAdmin();
        $body = self::parseInput();

        $required = ['title', 'category_id', 'points', 'difficulty', 'flag'];
        foreach ($required as $f) {
            if (empty($body[$f])) Response::error("$f is required");
        }

        $fileUrl = self::handleFileUpload();

        $id = DB::insert('ctf_challenges', [
            'title'       => $body['title'],
            'category_id' => (int)$body['category_id'],
            'points'      => (int)$body['points'],
            'difficulty'  => $body['difficulty'],
            'description' => $body['description'] ?? '',
            'flag'        => password_hash($body['flag'], PASSWORD_BCRYPT),
            'file_url'    => $fileUrl,
            'is_active'   => (int)($body['is_active'] ?? 1),
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        Response::created(DB::fetchOne('SELECT * FROM ctf_challenges WHERE id = ?', [$id]));
    }

    public static function updateChallenge(int $id): void
    {
        Auth::requireAdmin();
        $body = self::parseInput();

        $allowed = ['title', 'category_id', 'points', 'difficulty', 'description', 'is_active'];
        $data = [];
        foreach ($allowed as $f) {
            if (array_key_exists($f, $body)) $data[$f] = $body[$f];
        }
        if (!empty($body['flag'])) {
            $data['flag'] = password_hash($body['flag'], PASSWORD_BCRYPT);
        }
        $fileUrl = self::handleFileUpload();
        if ($fileUrl) $data['file_url'] = $fileUrl;

        if (!empty($data)) DB::update('ctf_challenges', $data, 'id = ?', [$id]);
        $row = DB::fetchOne('SELECT * FROM ctf_challenges WHERE id = ?', [$id]);
        if (!$row) Response::notFound();
        Response::json($row);
    }

    public static function deleteChallenge(int $id): void
    {
        Auth::requireAdmin();
        DB::query('DELETE FROM ctf_challenges WHERE id = ?', [$id]);
        Response::noContent();
    }

    public static function submitFlag(int $id): void
    {
        $user = Auth::require();
        $body = json_decode(file_get_contents('php://input'), true) ?? [];
        $flag = trim($body['flag'] ?? '');

        if (!$flag) Response::error('Flag is required');

        $challenge = DB::fetchOne('SELECT * FROM ctf_challenges WHERE id = ? AND is_active = 1', [$id]);
        if (!$challenge) Response::notFound('Challenge not found');

        $alreadySolved = DB::fetchOne(
            'SELECT id FROM ctf_solves WHERE user_id = ? AND challenge_id = ?',
            [$user['id'], $id]
        );
        if ($alreadySolved) {
            Response::json(['status' => 'already_solved', 'message' => 'Already solved']);
        }

        if (!password_verify($flag, $challenge['flag'])) {
            DB::insert('ctf_attempts', [
                'user_id'      => (int)$user['id'],
                'challenge_id' => $id,
                'flag_tried'   => $flag,
                'created_at'   => date('Y-m-d H:i:s'),
            ]);
            Response::json(['status' => 'incorrect', 'message' => 'Incorrect flag. Try again.'], 200);
        }

        DB::insert('ctf_solves', [
            'user_id'      => (int)$user['id'],
            'challenge_id' => $id,
            'solved_at'    => date('Y-m-d H:i:s'),
        ]);

        DB::query(
            'UPDATE users SET ctf_score = ctf_score + ? WHERE id = ?',
            [(int)$challenge['points'], $user['id']]
        );

        ActivityLog::log((int)$user['id'], 'ctf_solve', "Solved challenge: {$challenge['title']}");

        $solveCount = (int)(DB::fetchOne(
            'SELECT COUNT(*) as c FROM ctf_solves WHERE user_id = ?', [$user['id']]
        )['c'] ?? 0);
        BadgeController::award((int)$user['id'], 'ctf_solves', $solveCount);

        NotificationController::create(
            (int)$user['id'],
            '🚩 Challenge Solved!',
            "You solved \"{$challenge['title']}\" and earned {$challenge['points']} points!",
            'ctf',
            '/ctf'
        );

        EmailService::sendCtfSolved($user['email'], $user['username'], $challenge['title'], (int)$challenge['points']);

        Response::json(['status' => 'correct', 'message' => 'Correct Flag!', 'points' => (int)$challenge['points']]);
    }

    public static function listCompetitions(): void
    {
        $user = Auth::attempt();
        if ($user && (bool)$user['is_staff']) {
            $rows = DB::fetchAll('SELECT * FROM ctf_competitions ORDER BY event_date DESC');
        } else {
            $rows = DB::fetchAll(
                'SELECT * FROM ctf_competitions WHERE is_active = 1 ORDER BY event_date DESC'
            );
        }
        Response::json($rows);
    }

    public static function createCompetition(): void
    {
        Auth::requireAdmin();
        $body = json_decode(file_get_contents('php://input'), true) ?? [];
        if (empty($body['name'])) Response::error('Competition name required');

        $id = DB::insert('ctf_competitions', [
            'name'        => $body['name'],
            'description' => $body['description'] ?? '',
            'reg_start'   => $body['reg_start']   ?? null,
            'reg_end'     => $body['reg_end']      ?? null,
            'event_date'  => $body['event_date']   ?? null,
            'rules'       => $body['rules']        ?? '',
            'is_active'   => (int)($body['is_active'] ?? 1),
            'created_at'  => date('Y-m-d H:i:s'),
        ]);
        Response::created(DB::fetchOne('SELECT * FROM ctf_competitions WHERE id = ?', [$id]));
    }

    public static function updateCompetition(int $id): void
    {
        Auth::requireAdmin();
        $body = json_decode(file_get_contents('php://input'), true) ?? [];
        $allowed = ['name', 'description', 'reg_start', 'reg_end', 'event_date', 'rules', 'is_active'];
        $data = [];
        foreach ($allowed as $f) {
            if (array_key_exists($f, $body)) $data[$f] = $body[$f];
        }
        if (!empty($data)) DB::update('ctf_competitions', $data, 'id = ?', [$id]);
        $row = DB::fetchOne('SELECT * FROM ctf_competitions WHERE id = ?', [$id]);
        if (!$row) Response::notFound();
        Response::json($row);
    }

    public static function deleteCompetition(int $id): void
    {
        Auth::requireAdmin();
        DB::query('DELETE FROM ctf_competitions WHERE id = ?', [$id]);
        Response::noContent();
    }

    private static function parseInput(): array
    {
        $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
        if (str_contains($contentType, 'multipart/form-data')) {
            return array_merge($_POST, []);
        }
        return json_decode(file_get_contents('php://input'), true) ?? [];
    }

    private static function handleFileUpload(): ?string
    {
        if (empty($_FILES['file']['tmp_name'])) return null;
        $uploadDir = dirname(__DIR__, 2) . '/public/uploads/ctf/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
        $ext  = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
        $name = uniqid('ctf_', true) . '.' . $ext;
        move_uploaded_file($_FILES['file']['tmp_name'], $uploadDir . $name);
        return '/uploads/ctf/' . $name;
    }
}
