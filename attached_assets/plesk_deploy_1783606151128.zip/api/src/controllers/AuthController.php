<?php
declare(strict_types=1);

class AuthController
{
    public static function login(): void
    {
        $body = json_decode(file_get_contents('php://input'), true) ?? [];
        $username = trim($body['username'] ?? '');
        $password = $body['password'] ?? '';

        if (!$username || !$password) {
            Response::error('Username and password are required');
        }

        $user = DB::fetchOne(
            'SELECT * FROM users WHERE (username = ? OR email = ?) AND is_active = 1',
            [$username, $username]
        );

        if (!$user || !Auth::verifyPassword($password, $user['password'])) {
            Response::error('Invalid credentials', 401);
        }

        ActivityLog::log((int)$user['id'], 'login', 'User logged in');
        Response::json(Auth::makeTokenPair((int)$user['id']));
    }

    public static function refresh(): void
    {
        $body = json_decode(file_get_contents('php://input'), true) ?? [];
        $token = $body['refresh'] ?? '';

        if (!$token) {
            Response::error('Refresh token required');
        }

        try {
            $payload = JWT::decode($token, Auth::getSecret());
            if (($payload['type'] ?? '') !== 'refresh') {
                throw new RuntimeException('Wrong token type');
            }

            $user = DB::fetchOne('SELECT id, is_active FROM users WHERE id = ?', [$payload['user_id']]);
            if (!$user || !(bool)$user['is_active']) {
                Response::unauthorized('User not found or inactive');
            }

            $access = JWT::encode(['user_id' => (int)$user['id'], 'type' => 'access'], Auth::getSecret(), 3600);
            Response::json(['access' => $access]);
        } catch (RuntimeException $e) {
            Response::error($e->getMessage(), 401);
        }
    }

    public static function register(): void
    {
        $body = json_decode(file_get_contents('php://input'), true) ?? [];
        $username = trim($body['username'] ?? '');
        $email    = trim($body['email']    ?? '');
        $password = $body['password']      ?? '';

        if (!$username || !$email || !$password) {
            Response::error('Username, email, and password are required');
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            Response::error('Invalid email format');
        }
        if (strlen($password) < 8) {
            Response::error('Password must be at least 8 characters');
        }

        $exists = DB::fetchOne(
            'SELECT id FROM users WHERE username = ? OR email = ?',
            [$username, $email]
        );
        if ($exists) {
            Response::error('Username or email already exists');
        }

        $id = DB::insert('users', [
            'username'   => $username,
            'email'      => $email,
            'password'   => Auth::hashPassword($password),
            'is_active'  => 1,
            'is_staff'   => 0,
            'is_superuser' => 0,
            'ctf_score'  => 0,
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        try {
            ActivityLog::log($id, 'register', "New user registered: $username");
        } catch (Throwable $e) {}

        try {
            NotificationController::create($id, '👋 مرحباً بك في 249Shadow!',
                'حسابك جاهز. ابدأ بتحديات الـ CTF أو سجّل في إحدى الدورات.',
                'welcome', '/courses');
        } catch (Throwable $e) {}

        try {
            EmailService::sendWelcome($email, $username);
        } catch (Throwable $e) {}

        Response::created(Auth::makeTokenPair($id));
    }
}
