<?php
declare(strict_types=1);

class LabController
{
    public static function list(): void
    {
        $user = Auth::attempt();
        if ($user && (bool)$user['is_staff']) {
            $rows = DB::fetchAll('SELECT * FROM lab_challenges ORDER BY id DESC');
        } else {
            Auth::require();
            $rows = DB::fetchAll('SELECT * FROM lab_challenges WHERE is_active = 1 ORDER BY id DESC');
        }
        Response::json($rows);
    }

    public static function get(int $id): void
    {
        $user = Auth::require();
        $extra = (bool)$user['is_staff'] ? '' : 'AND is_active = 1';
        $row = DB::fetchOne("SELECT * FROM lab_challenges WHERE id = ? $extra", [$id]);
        if (!$row) Response::notFound();
        Response::json($row);
    }

    public static function create(): void
    {
        Auth::requireAdmin();
        $body = self::parseInput();
        if (empty($body['title'])) Response::error('Title required');

        $fileUrl = self::handleFileUpload();

        $id = DB::insert('lab_challenges', [
            'title'       => $body['title'],
            'description' => $body['description'] ?? '',
            'category'    => $body['category']    ?? '',
            'difficulty'  => $body['difficulty']  ?? 'Easy',
            'points'      => (int)($body['points'] ?? 0),
            'file_url'    => $fileUrl,
            'is_active'   => (int)($body['is_active'] ?? 1),
            'created_at'  => date('Y-m-d H:i:s'),
        ]);
        Response::created(DB::fetchOne('SELECT * FROM lab_challenges WHERE id = ?', [$id]));
    }

    public static function update(int $id): void
    {
        Auth::requireAdmin();
        $body = self::parseInput();
        $allowed = ['title', 'description', 'category', 'difficulty', 'points', 'is_active'];
        $data = [];
        foreach ($allowed as $f) {
            if (array_key_exists($f, $body)) $data[$f] = $body[$f];
        }
        $file = self::handleFileUpload();
        if ($file) $data['file_url'] = $file;

        if (!empty($data)) DB::update('lab_challenges', $data, 'id = ?', [$id]);
        $row = DB::fetchOne('SELECT * FROM lab_challenges WHERE id = ?', [$id]);
        if (!$row) Response::notFound();
        Response::json($row);
    }

    public static function delete(int $id): void
    {
        Auth::requireAdmin();
        DB::query('DELETE FROM lab_challenges WHERE id = ?', [$id]);
        Response::noContent();
    }

    private static function parseInput(): array
    {
        $ct = $_SERVER['CONTENT_TYPE'] ?? '';
        if (str_contains($ct, 'multipart/form-data')) return $_POST;
        return json_decode(file_get_contents('php://input'), true) ?? [];
    }

    private static function handleFileUpload(): ?string
    {
        if (empty($_FILES['file']['tmp_name'])) return null;
        $dir = dirname(__DIR__, 2) . '/public/uploads/lab/';
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        $ext  = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
        $name = uniqid('lab_', true) . '.' . $ext;
        move_uploaded_file($_FILES['file']['tmp_name'], $dir . $name);
        return '/uploads/lab/' . $name;
    }
}
