<?php
declare(strict_types=1);

class TeamController
{
    public static function list(): void
    {
        $teams = DB::fetchAll(
            'SELECT t.*, u.username as creator_name,
             (SELECT COUNT(*) FROM ctf_team_members WHERE team_id = t.id) as member_count
             FROM ctf_teams t
             LEFT JOIN users u ON u.id = t.created_by
             ORDER BY t.created_at DESC'
        );
        Response::json($teams);
    }

    public static function get(int $id): void
    {
        $team = DB::fetchOne(
            'SELECT t.*, u.username as creator_name FROM ctf_teams t
             LEFT JOIN users u ON u.id = t.created_by WHERE t.id = ?',
            [$id]
        );
        if (!$team) Response::notFound('Team not found');

        $members = DB::fetchAll(
            'SELECT m.role, m.joined_at, u.id, u.username, u.avatar_url, u.ctf_score
             FROM ctf_team_members m JOIN users u ON u.id = m.user_id
             WHERE m.team_id = ?
             ORDER BY m.joined_at ASC',
            [$id]
        );
        $team['members'] = $members;
        Response::json($team);
    }

    public static function myTeam(): void
    {
        $user = Auth::require();
        $member = DB::fetchOne(
            'SELECT team_id FROM ctf_team_members WHERE user_id = ?',
            [$user['id']]
        );
        if (!$member) {
            Response::json(null);
            return;
        }
        self::get((int)$member['team_id']);
    }

    public static function create(): void
    {
        $user = Auth::require();
        $body = json_decode(file_get_contents('php://input'), true) ?? [];
        $name = trim($body['name'] ?? '');
        $desc = trim($body['description'] ?? '');

        if (!$name) Response::error('Team name is required');

        $existing = DB::fetchOne('SELECT id FROM ctf_teams WHERE name = ?', [$name]);
        if ($existing) Response::error('Team name already taken');

        $alreadyIn = DB::fetchOne(
            'SELECT id FROM ctf_team_members WHERE user_id = ?',
            [$user['id']]
        );
        if ($alreadyIn) Response::error('You are already in a team. Leave first.');

        $inviteCode = strtoupper(substr(md5(uniqid((string)$user['id'], true)), 0, 8));

        $teamId = DB::insert('ctf_teams', [
            'name'        => $name,
            'description' => $desc,
            'invite_code' => $inviteCode,
            'created_by'  => $user['id'],
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        DB::insert('ctf_team_members', [
            'team_id'   => $teamId,
            'user_id'   => $user['id'],
            'role'      => 'leader',
            'joined_at' => date('Y-m-d H:i:s'),
        ]);

        ActivityLog::log($user['id'], 'team_create', "Created team: $name");

        Response::created(['id' => $teamId, 'name' => $name, 'invite_code' => $inviteCode]);
    }

    public static function join(): void
    {
        $user = Auth::require();
        $body = json_decode(file_get_contents('php://input'), true) ?? [];
        $code = strtoupper(trim($body['invite_code'] ?? ''));

        if (!$code) Response::error('Invite code is required');

        $team = DB::fetchOne('SELECT * FROM ctf_teams WHERE invite_code = ?', [$code]);
        if (!$team) Response::error('Invalid invite code');

        $alreadyIn = DB::fetchOne(
            'SELECT id FROM ctf_team_members WHERE user_id = ?',
            [$user['id']]
        );
        if ($alreadyIn) Response::error('You are already in a team. Leave first.');

        $count = DB::fetchOne(
            'SELECT COUNT(*) as c FROM ctf_team_members WHERE team_id = ?',
            [$team['id']]
        );
        if ((int)$count['c'] >= 5) Response::error('Team is full (max 5 members)');

        DB::insert('ctf_team_members', [
            'team_id'   => $team['id'],
            'user_id'   => $user['id'],
            'role'      => 'member',
            'joined_at' => date('Y-m-d H:i:s'),
        ]);

        ActivityLog::log($user['id'], 'team_join', "Joined team: {$team['name']}");

        Response::json(['message' => "Joined team {$team['name']}", 'team_id' => $team['id']]);
    }

    public static function leave(): void
    {
        $user = Auth::require();
        $member = DB::fetchOne(
            'SELECT m.*, t.created_by FROM ctf_team_members m
             JOIN ctf_teams t ON t.id = m.team_id
             WHERE m.user_id = ?',
            [$user['id']]
        );
        if (!$member) Response::error('You are not in any team');

        if ((int)$member['created_by'] === (int)$user['id']) {
            $others = DB::fetchAll(
                'SELECT user_id FROM ctf_team_members WHERE team_id = ? AND user_id != ?',
                [$member['team_id'], $user['id']]
            );
            if (count($others) > 0) {
                DB::update('ctf_team_members', ['role' => 'leader'],
                    'team_id = ? AND user_id = ?',
                    [$member['team_id'], $others[0]['user_id']]
                );
                DB::update('ctf_teams', ['created_by' => $others[0]['user_id']],
                    'id = ?', [$member['team_id']]
                );
            } else {
                DB::query('DELETE FROM ctf_teams WHERE id = ?', [$member['team_id']]);
            }
        }

        DB::query('DELETE FROM ctf_team_members WHERE user_id = ? AND team_id = ?',
            [$user['id'], $member['team_id']]
        );

        ActivityLog::log($user['id'], 'team_leave', 'Left team');
        Response::json(['message' => 'Left team successfully']);
    }

    public static function deleteTeam(int $id): void
    {
        Auth::requireAdmin();
        DB::query('DELETE FROM ctf_teams WHERE id = ?', [$id]);
        Response::noContent();
    }
}
