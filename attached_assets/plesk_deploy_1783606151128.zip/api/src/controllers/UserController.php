<?php
declare(strict_types=1);

class UserController
{
    private static function sanitizeUser(array $u): array
    {
        unset($u['password']);
        return $u;
    }

    public static function profile(): void
    {
        $user = Auth::require();
        Response::json(self::sanitizeUser($user));
    }

    public static function updateProfile(): void
    {
        $user = Auth::require();
        $body = json_decode(file_get_contents('php://input'), true) ?? [];

        $allowed = ['bio', 'avatar_url', 'first_name', 'last_name'];
        $data = [];
        foreach ($allowed as $field) {
            if (isset($body[$field])) {
                $data[$field] = $body[$field];
            }
        }

        if (!empty($body['password'])) {
            if (strlen($body['password']) < 8) {
                Response::error('Password must be at least 8 characters');
            }
            $data['password'] = Auth::hashPassword($body['password']);
        }

        if (!empty($data)) {
            DB::update('users', $data, 'id = ?', [$user['id']]);
        }

        $updated = DB::fetchOne('SELECT * FROM users WHERE id = ?', [$user['id']]);
        Response::json(self::sanitizeUser($updated));
    }

    public static function list(): void
    {
        Auth::requireAdmin();
        $users = DB::fetchAll('SELECT * FROM users ORDER BY id DESC');
        Response::json(array_map([self::class, 'sanitizeUser'], $users));
    }

    public static function create(): void
    {
        Auth::requireAdmin();
        $body = json_decode(file_get_contents('php://input'), true) ?? [];

        $required = ['username', 'email', 'password'];
        foreach ($required as $f) {
            if (empty($body[$f])) Response::error("$f is required");
        }

        $exists = DB::fetchOne(
            'SELECT id FROM users WHERE username = ? OR email = ?',
            [$body['username'], $body['email']]
        );
        if ($exists) Response::error('Username or email already exists');

        $id = DB::insert('users', [
            'username'    => $body['username'],
            'email'       => $body['email'],
            'password'    => Auth::hashPassword($body['password']),
            'is_active'   => (int)($body['is_active']    ?? 1),
            'is_staff'    => (int)($body['is_staff']     ?? 0),
            'is_superuser'=> (int)($body['is_superuser'] ?? 0),
            'ctf_score'   => (int)($body['ctf_score']   ?? 0),
            'created_at'  => date('Y-m-d H:i:s'),
        ]);

        $user = DB::fetchOne('SELECT * FROM users WHERE id = ?', [$id]);
        Response::created(self::sanitizeUser($user));
    }

    public static function update(int $id): void
    {
        Auth::requireAdmin();
        $body = json_decode(file_get_contents('php://input'), true) ?? [];

        $allowed = ['username', 'email', 'is_active', 'is_staff', 'is_superuser', 'ctf_score', 'bio'];
        $data = [];
        foreach ($allowed as $f) {
            if (array_key_exists($f, $body)) {
                $data[$f] = $body[$f];
            }
        }
        if (!empty($body['password'])) {
            $data['password'] = Auth::hashPassword($body['password']);
        }

        if (!empty($data)) {
            DB::update('users', $data, 'id = ?', [$id]);
        }

        $user = DB::fetchOne('SELECT * FROM users WHERE id = ?', [$id]);
        if (!$user) Response::notFound();
        Response::json(self::sanitizeUser($user));
    }

    public static function delete(int $id): void
    {
        Auth::requireAdmin();
        DB::query('DELETE FROM users WHERE id = ?', [$id]);
        Response::noContent();
    }

    public static function stats(): void
    {
        Auth::requireAdmin();
        Response::json([
            'users_count'      => (int)DB::fetchOne('SELECT COUNT(*) as c FROM users')['c'],
            'challenges_count' => (int)DB::fetchOne('SELECT COUNT(*) as c FROM ctf_challenges')['c'],
            'courses_count'    => (int)DB::fetchOne('SELECT COUNT(*) as c FROM courses')['c'],
            'projects_count'   => (int)DB::fetchOne('SELECT COUNT(*) as c FROM projects')['c'],
            'solves_count'     => (int)DB::fetchOne('SELECT COUNT(*) as c FROM ctf_solves')['c'],
            'recent_users'     => array_map(
                [self::class, 'sanitizeUser'],
                DB::fetchAll('SELECT * FROM users ORDER BY id DESC LIMIT 5')
            ),
        ]);
    }

    public static function leaderboard(): void
    {
        $rows = DB::fetchAll(
            'SELECT id, username, ctf_score, avatar_url FROM users WHERE is_active = 1 ORDER BY ctf_score DESC LIMIT 50'
        );
        Response::json($rows);
    }

    public static function groups(): void
    {
        Auth::requireAdmin();
        $groups = DB::fetchAll('SELECT * FROM groups ORDER BY id');
        Response::json($groups);
    }

    public static function createGroup(): void
    {
        Auth::requireAdmin();
        $body = json_decode(file_get_contents('php://input'), true) ?? [];
        if (empty($body['name'])) Response::error('Group name required');
        $id = DB::insert('groups', ['name' => $body['name'], 'permissions' => $body['permissions'] ?? '']);
        $group = DB::fetchOne('SELECT * FROM groups WHERE id = ?', [$id]);
        Response::created($group);
    }

    public static function deleteGroup(int $id): void
    {
        Auth::requireAdmin();
        DB::query('DELETE FROM groups WHERE id = ?', [$id]);
        Response::noContent();
    }
}
