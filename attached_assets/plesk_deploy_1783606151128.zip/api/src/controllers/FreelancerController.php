<?php
declare(strict_types=1);

class FreelancerController
{
    public static function listTasks(): void
    {
        $rows = DB::fetchAll('SELECT * FROM freelancer_tasks ORDER BY id DESC');
        Response::json($rows);
    }

    public static function getTask(int $id): void
    {
        $row = DB::fetchOne('SELECT * FROM freelancer_tasks WHERE id = ?', [$id]);
        if (!$row) Response::notFound();
        Response::json($row);
    }

    public static function createTask(): void
    {
        Auth::requireAdmin();
        $body = json_decode(file_get_contents('php://input'), true) ?? [];
        if (empty($body['title'])) Response::error('Title required');

        $id = DB::insert('freelancer_tasks', [
            'title'       => $body['title'],
            'description' => $body['description'] ?? '',
            'skills'      => $body['skills']      ?? '',
            'reward'      => $body['reward']       ?? '',
            'is_money'    => (int)($body['is_money']  ?? 0),
            'is_active'   => (int)($body['is_active'] ?? 1),
            'created_at'  => date('Y-m-d H:i:s'),
        ]);
        Response::created(DB::fetchOne('SELECT * FROM freelancer_tasks WHERE id = ?', [$id]));
    }

    public static function updateTask(int $id): void
    {
        Auth::requireAdmin();
        $body = json_decode(file_get_contents('php://input'), true) ?? [];
        $allowed = ['title', 'description', 'skills', 'reward', 'is_money', 'is_active'];
        $data = [];
        foreach ($allowed as $f) {
            if (array_key_exists($f, $body)) $data[$f] = $body[$f];
        }
        if (!empty($data)) DB::update('freelancer_tasks', $data, 'id = ?', [$id]);
        $row = DB::fetchOne('SELECT * FROM freelancer_tasks WHERE id = ?', [$id]);
        if (!$row) Response::notFound();
        Response::json($row);
    }

    public static function deleteTask(int $id): void
    {
        Auth::requireAdmin();
        DB::query('DELETE FROM freelancer_tasks WHERE id = ?', [$id]);
        Response::noContent();
    }

    public static function listApplications(): void
    {
        Auth::requireAdmin();
        $rows = DB::fetchAll(
            'SELECT a.*, t.title as task_title, u.username FROM freelancer_applications a
             LEFT JOIN freelancer_tasks t ON t.id = a.task_id
             LEFT JOIN users u ON u.id = a.user_id
             ORDER BY a.id DESC'
        );
        Response::json($rows);
    }

    public static function apply(int $taskId): void
    {
        $user = Auth::require();
        $task = DB::fetchOne('SELECT id FROM freelancer_tasks WHERE id = ? AND is_active = 1', [$taskId]);
        if (!$task) Response::notFound('Task not found');

        $exists = DB::fetchOne(
            'SELECT id FROM freelancer_applications WHERE user_id = ? AND task_id = ?',
            [$user['id'], $taskId]
        );
        if ($exists) Response::error('Already applied');

        $body = json_decode(file_get_contents('php://input'), true) ?? [];
        $id = DB::insert('freelancer_applications', [
            'user_id'    => (int)$user['id'],
            'task_id'    => $taskId,
            'contact'    => $body['contact']    ?? '',
            'message'    => $body['message']    ?? '',
            'applied_at' => date('Y-m-d H:i:s'),
        ]);
        Response::created(['id' => $id, 'detail' => 'Application submitted']);
    }

    public static function deleteApplication(int $id): void
    {
        Auth::requireAdmin();
        DB::query('DELETE FROM freelancer_applications WHERE id = ?', [$id]);
        Response::noContent();
    }
}
