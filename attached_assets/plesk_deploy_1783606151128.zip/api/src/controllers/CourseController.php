<?php
declare(strict_types=1);

class CourseController
{
    public static function list(): void
    {
        $user = Auth::attempt();
        if ($user && (bool)$user['is_staff']) {
            $rows = DB::fetchAll('SELECT * FROM courses ORDER BY id DESC');
        } else {
            $rows = DB::fetchAll('SELECT * FROM courses WHERE is_published = 1 ORDER BY id DESC');
        }

        if ($user) {
            $enrolled = DB::fetchAll(
                'SELECT course_id FROM enrollments WHERE user_id = ?', [$user['id']]
            );
            $enrolledIds = array_column($enrolled, 'course_id');
            $rows = array_map(function ($c) use ($enrolledIds) {
                $c['is_enrolled'] = in_array($c['id'], $enrolledIds);
                return $c;
            }, $rows);
        } else {
            $rows = array_map(fn($c) => array_merge($c, ['is_enrolled' => false]), $rows);
        }

        Response::json($rows);
    }

    public static function get(int $id): void
    {
        $user = Auth::attempt();
        $extra = ($user && (bool)$user['is_staff']) ? '' : 'AND is_published = 1';
        $course = DB::fetchOne("SELECT * FROM courses WHERE id = ? $extra", [$id]);
        if (!$course) Response::notFound();

        $chapters = DB::fetchAll(
            'SELECT * FROM chapters WHERE course_id = ? ORDER BY order_num', [$id]
        );
        foreach ($chapters as &$ch) {
            $ch['lessons'] = DB::fetchAll(
                'SELECT * FROM lessons WHERE chapter_id = ? ORDER BY order_num', [$ch['id']]
            );
        }
        $course['chapters'] = $chapters;

        if ($user) {
            $course['is_enrolled'] = (bool)DB::fetchOne(
                'SELECT id FROM enrollments WHERE user_id = ? AND course_id = ?',
                [$user['id'], $id]
            );
        } else {
            $course['is_enrolled'] = false;
        }

        Response::json($course);
    }

    public static function create(): void
    {
        Auth::requireAdmin();
        $body = self::parseInput();
        if (empty($body['title'])) Response::error('Title is required');

        $imageUrl = self::handleFileUpload('thumbnail', 'courses');

        $id = DB::insert('courses', [
            'title'          => $body['title'],
            'description'    => $body['description']    ?? '',
            'instructor_name'=> $body['instructor_name']?? '',
            'instructor_bio' => $body['instructor_bio'] ?? '',
            'price'          => (float)($body['price']  ?? 0),
            'thumbnail_url'  => $imageUrl,
            'is_published'   => (int)($body['is_published'] ?? 0),
            'created_at'     => date('Y-m-d H:i:s'),
        ]);
        Response::created(DB::fetchOne('SELECT * FROM courses WHERE id = ?', [$id]));
    }

    public static function update(int $id): void
    {
        Auth::requireAdmin();
        $body = self::parseInput();
        $allowed = ['title', 'description', 'instructor_name', 'instructor_bio', 'price', 'is_published'];
        $data = [];
        foreach ($allowed as $f) {
            if (array_key_exists($f, $body)) $data[$f] = $body[$f];
        }
        $img = self::handleFileUpload('thumbnail', 'courses');
        if ($img) $data['thumbnail_url'] = $img;

        if (!empty($data)) DB::update('courses', $data, 'id = ?', [$id]);
        $row = DB::fetchOne('SELECT * FROM courses WHERE id = ?', [$id]);
        if (!$row) Response::notFound();
        Response::json($row);
    }

    public static function delete(int $id): void
    {
        Auth::requireAdmin();
        DB::query('DELETE FROM courses WHERE id = ?', [$id]);
        Response::noContent();
    }

    public static function enroll(int $id): void
    {
        $user = Auth::require();
        $course = DB::fetchOne('SELECT id, price FROM courses WHERE id = ? AND is_published = 1', [$id]);
        if (!$course) Response::notFound();

        $exists = DB::fetchOne(
            'SELECT id FROM enrollments WHERE user_id = ? AND course_id = ?',
            [$user['id'], $id]
        );
        if ($exists) {
            Response::json(['detail' => 'Already enrolled']);
        }

        DB::insert('enrollments', [
            'user_id'     => (int)$user['id'],
            'course_id'   => $id,
            'enrolled_at' => date('Y-m-d H:i:s'),
        ]);
        Response::created(['detail' => 'Enrolled successfully']);
    }

    public static function chapters(int $courseId): void
    {
        Auth::requireAdmin();
        $chapters = DB::fetchAll(
            'SELECT * FROM chapters WHERE course_id = ? ORDER BY order_num', [$courseId]
        );
        foreach ($chapters as &$ch) {
            $ch['lessons'] = DB::fetchAll(
                'SELECT * FROM lessons WHERE chapter_id = ? ORDER BY order_num', [$ch['id']]
            );
        }
        Response::json($chapters);
    }

    public static function createChapter(int $courseId): void
    {
        Auth::requireAdmin();
        $body = json_decode(file_get_contents('php://input'), true) ?? [];
        if (empty($body['title'])) Response::error('Title required');
        $id = DB::insert('chapters', [
            'course_id' => $courseId,
            'title'     => $body['title'],
            'order_num' => (int)($body['order_num'] ?? 0),
        ]);
        Response::created(DB::fetchOne('SELECT * FROM chapters WHERE id = ?', [$id]));
    }

    public static function updateChapter(int $id): void
    {
        Auth::requireAdmin();
        $body = json_decode(file_get_contents('php://input'), true) ?? [];
        $data = [];
        foreach (['title', 'order_num'] as $f) {
            if (array_key_exists($f, $body)) $data[$f] = $body[$f];
        }
        if (!empty($data)) DB::update('chapters', $data, 'id = ?', [$id]);
        Response::json(DB::fetchOne('SELECT * FROM chapters WHERE id = ?', [$id]));
    }

    public static function deleteChapter(int $id): void
    {
        Auth::requireAdmin();
        DB::query('DELETE FROM chapters WHERE id = ?', [$id]);
        Response::noContent();
    }

    public static function createLesson(int $chapterId): void
    {
        Auth::requireAdmin();
        $body = self::parseInput();
        if (empty($body['title'])) Response::error('Title required');
        $fileUrl = self::handleFileUpload('file', 'lessons');
        $id = DB::insert('lessons', [
            'chapter_id'   => $chapterId,
            'title'        => $body['title'],
            'video_url'    => $body['video_url']   ?? '',
            'file_url'     => $fileUrl,
            'duration'     => $body['duration']    ?? '',
            'order_num'    => (int)($body['order_num'] ?? 0),
            'is_free'      => (int)($body['is_free']   ?? 0),
        ]);
        Response::created(DB::fetchOne('SELECT * FROM lessons WHERE id = ?', [$id]));
    }

    public static function updateLesson(int $id): void
    {
        Auth::requireAdmin();
        $body = self::parseInput();
        $allowed = ['title', 'video_url', 'duration', 'order_num', 'is_free'];
        $data = [];
        foreach ($allowed as $f) {
            if (array_key_exists($f, $body)) $data[$f] = $body[$f];
        }
        $fileUrl = self::handleFileUpload('file', 'lessons');
        if ($fileUrl) $data['file_url'] = $fileUrl;

        if (!empty($data)) DB::update('lessons', $data, 'id = ?', [$id]);
        Response::json(DB::fetchOne('SELECT * FROM lessons WHERE id = ?', [$id]));
    }

    public static function deleteLesson(int $id): void
    {
        Auth::requireAdmin();
        DB::query('DELETE FROM lessons WHERE id = ?', [$id]);
        Response::noContent();
    }

    private static function parseInput(): array
    {
        $ct = $_SERVER['CONTENT_TYPE'] ?? '';
        if (str_contains($ct, 'multipart/form-data')) {
            return $_POST;
        }
        return json_decode(file_get_contents('php://input'), true) ?? [];
    }

    private static function handleFileUpload(string $field, string $subfolder): ?string
    {
        if (empty($_FILES[$field]['tmp_name'])) return null;
        $dir = dirname(__DIR__, 2) . "/public/uploads/$subfolder/";
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        $ext  = pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION);
        $name = uniqid("{$subfolder}_", true) . '.' . $ext;
        move_uploaded_file($_FILES[$field]['tmp_name'], $dir . $name);
        return "/uploads/$subfolder/$name";
    }
}
