<?php
declare(strict_types=1);

class NotificationController
{
    public static function myNotifications(): void
    {
        $user = Auth::require();
        $notifications = DB::fetchAll(
            'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50',
            [$user['id']]
        );
        $unread = DB::fetchOne(
            'SELECT COUNT(*) as c FROM notifications WHERE user_id = ? AND is_read = 0',
            [$user['id']]
        );
        Response::json([
            'notifications' => $notifications,
            'unread_count'  => (int)($unread['c'] ?? 0),
        ]);
    }

    public static function markRead(int $id): void
    {
        $user = Auth::require();
        DB::query(
            'UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?',
            [$id, $user['id']]
        );
        Response::json(['success' => true]);
    }

    public static function markAllRead(): void
    {
        $user = Auth::require();
        DB::query(
            'UPDATE notifications SET is_read = 1 WHERE user_id = ?',
            [$user['id']]
        );
        Response::json(['success' => true]);
    }

    public static function create(
        int $userId,
        string $title,
        string $message,
        string $type = 'info',
        string $link = ''
    ): void {
        DB::insert('notifications', [
            'user_id'    => $userId,
            'title'      => $title,
            'message'    => $message,
            'type'       => $type,
            'is_read'    => 0,
            'link'       => $link,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }

    public static function broadcast(): void
    {
        Auth::requireAdmin();
        $body = json_decode(file_get_contents('php://input'), true) ?? [];
        $title   = trim($body['title']   ?? '');
        $message = trim($body['message'] ?? '');
        $link    = trim($body['link']    ?? '');

        if (!$title || !$message) Response::error('Title and message are required');

        $users = DB::fetchAll('SELECT id FROM users WHERE is_active = 1');
        foreach ($users as $user) {
            self::create((int)$user['id'], $title, $message, 'announcement', $link);
        }
        Response::json(['sent_to' => count($users)]);
    }

    public static function delete(int $id): void
    {
        $user = Auth::require();
        DB::query('DELETE FROM notifications WHERE id = ? AND user_id = ?', [$id, $user['id']]);
        Response::noContent();
    }
}
