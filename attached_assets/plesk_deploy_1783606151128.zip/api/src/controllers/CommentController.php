<?php
declare(strict_types=1);

class CommentController
{
    public static function listByCourse(int $courseId): void
    {
        $comments = DB::fetchAll(
            'SELECT c.*, u.username, u.avatar_url
             FROM course_comments c
             JOIN users u ON u.id = c.user_id
             WHERE c.course_id = ?
             ORDER BY c.created_at DESC',
            [$courseId]
        );
        Response::json($comments);
    }

    public static function create(int $courseId): void
    {
        $user = Auth::require();
        $body = json_decode(file_get_contents('php://input'), true) ?? [];
        $comment = trim($body['comment'] ?? '');

        if (!$comment) Response::error('Comment cannot be empty');
        if (strlen($comment) > 1000) Response::error('Comment too long (max 1000 chars)');

        $id = DB::insert('course_comments', [
            'course_id'  => $courseId,
            'user_id'    => $user['id'],
            'comment'    => $comment,
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        ActivityLog::log($user['id'], 'course_comment', "Commented on course #$courseId");

        $row = DB::fetchOne(
            'SELECT c.*, u.username, u.avatar_url FROM course_comments c JOIN users u ON u.id = c.user_id WHERE c.id = ?',
            [$id]
        );
        Response::created($row);
    }

    public static function delete(int $commentId): void
    {
        $user = Auth::require();
        $comment = DB::fetchOne('SELECT * FROM course_comments WHERE id = ?', [$commentId]);
        if (!$comment) Response::notFound('Comment not found');

        if ($comment['user_id'] !== (int)$user['id'] && !(bool)$user['is_staff']) {
            Response::forbidden('Cannot delete another user\'s comment');
        }

        DB::query('DELETE FROM course_comments WHERE id = ?', [$commentId]);
        Response::noContent();
    }
}
