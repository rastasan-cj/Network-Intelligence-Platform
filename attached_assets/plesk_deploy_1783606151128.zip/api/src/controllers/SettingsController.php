<?php
declare(strict_types=1);

class SettingsController
{
    public static function get(): void
    {
        $settings = DB::fetchOne('SELECT * FROM site_settings WHERE id = 1');
        if (!$settings) {
            $settings = self::defaults();
        }
        Response::json($settings);
    }

    public static function update(): void
    {
        Auth::requireAdmin();
        $body = json_decode(file_get_contents('php://input'), true) ?? [];

        $allowed = [
            'site_name', 'site_description', 'contact_email',
            'maintenance_mode', 'ctf_enabled', 'registration_enabled',
            'allow_registration', 'max_flag_attempts',
        ];

        $existing = DB::fetchOne('SELECT id FROM site_settings WHERE id = 1');
        $data = [];
        foreach ($allowed as $f) {
            if (array_key_exists($f, $body)) $data[$f] = $body[$f];
        }

        if ($existing) {
            DB::update('site_settings', $data, 'id = 1');
        } else {
            $data['id'] = 1;
            DB::insert('site_settings', array_merge(self::defaults(), $data));
        }

        Response::json(DB::fetchOne('SELECT * FROM site_settings WHERE id = 1'));
    }

    private static function defaults(): array
    {
        return [
            'site_name'             => '249Shadow',
            'site_description'      => 'Cybersecurity Learning Platform',
            'contact_email'         => 'admin@249shadow.com',
            'maintenance_mode'      => 0,
            'ctf_enabled'           => 1,
            'registration_enabled'  => 1,
            'allow_registration'    => 1,
            'max_flag_attempts'     => 10,
        ];
    }

    public static function latestContent(): void
    {
        $course    = DB::fetchOne('SELECT id, title, thumbnail_url FROM courses WHERE is_published = 1 ORDER BY id DESC LIMIT 1');
        $challenge = DB::fetchOne('SELECT id, title FROM ctf_challenges WHERE is_active = 1 ORDER BY id DESC LIMIT 1');
        $task      = DB::fetchOne('SELECT id, title FROM freelancer_tasks WHERE is_active = 1 ORDER BY id DESC LIMIT 1');

        Response::json([
            'latest_course'    => $course,
            'latest_challenge' => $challenge,
            'latest_task'      => $task,
        ]);
    }
}
